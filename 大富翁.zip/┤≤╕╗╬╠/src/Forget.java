import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JOptionPane;

/*
 * Forget.java
 *
 * Created on __DATE__, __TIME__
 */

/**
 *
 * @author  __USER__
 */
public class Forget extends javax.swing.JFrame {

	/** Creates new form Forget */
	public Forget() {
		initComponents();
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {
		
		//��������λ�ã�ʹ�Ի������   
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();   
        this.setLocation( (int) (screenSize.width - 500) / 2 + 50,   
                        (int) (screenSize.height - 800) / 2 + 150);   
        this.setResizable(false);

		jPanel1 = new javax.swing.JPanel();
		jButton1 = new javax.swing.JButton();
		jButton3 = new javax.swing.JButton();
		jButton2 = new javax.swing.JButton();
		jLabel3 = new javax.swing.JLabel();
		jLabel2 = new javax.swing.JLabel();
		jLabel1 = new javax.swing.JLabel();
		jTextField1 = new javax.swing.JTextField();
		jTextField2 = new javax.swing.JTextField();
		jTextField3 = new javax.swing.JTextField();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jPanel1.setBackground(new java.awt.Color(255, 255, 255));

		jButton1.setBackground(new java.awt.Color(255, 255, 255));
		jButton1.setFont(new java.awt.Font("���Ŀ���", 0, 14));
		jButton1.setText("\u83b7\u53d6\u90ae\u7bb1\u9a8c\u8bc1\u7801");
		jButton1.setBorder(null);
		jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseEntered(java.awt.event.MouseEvent evt) {
				jButton1MouseEntered(evt);
			}
		});
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton1ActionPerformed(evt);
			}
		});

		jButton3.setBackground(new java.awt.Color(255, 255, 255));
		jButton3.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jButton3.setForeground(new java.awt.Color(0, 0, 204));
		jButton3.setText("\u9000\u51fa");
		jButton3.setBorder(null);
		jButton3.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton3ActionPerformed(evt);
			}
		});

		jButton2.setBackground(new java.awt.Color(255, 255, 255));
		jButton2.setFont(new java.awt.Font("���Ŀ���", 1, 24));
		jButton2.setForeground(new java.awt.Color(153, 153, 0));
		jButton2.setText("\u767b     \u5f55");
		jButton2.setBorder(null);
		jButton2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton2ActionPerformed(evt);
			}
		});

		jLabel3.setBackground(new java.awt.Color(255, 255, 255));
		jLabel3.setFont(new java.awt.Font("���Ŀ���", 1, 20));
		jLabel3.setText("\u9a8c\u8bc1\u7801");

		jLabel2.setBackground(new java.awt.Color(255, 255, 255));
		jLabel2.setFont(new java.awt.Font("���Ŀ���", 1, 20));
		jLabel2.setText("\u5bc6  \u7801  ");

		jLabel1.setBackground(new java.awt.Color(255, 255, 255));
		jLabel1.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jLabel1.setText("\u90ae\u7bb1\u540d");

		jTextField1.setFont(new java.awt.Font("���Ŀ���", 0, 14));
		jTextField1.setForeground(new java.awt.Color(204, 204, 204));
		jTextField1.setText("\u8bf7\u8f93\u5165\u90ae\u7bb1\u540d");
		jTextField1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
		jTextField1.setMargin(new java.awt.Insets(0, 0, 0, 0));
		
		jTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyTyped(java.awt.event.KeyEvent evt) {
				jTextField1jTextFieldkeyTyped(evt);
			}
		});

		jTextField2.setFont(new java.awt.Font("���Ŀ���", 0, 14));
		jTextField2.setForeground(new java.awt.Color(204, 204, 204));
		jTextField2.setText("\u8bf7\u8f93\u5165\u5bc6\u7801");
		jTextField2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
		jTextField2.setMargin(new java.awt.Insets(0, 0, 0, 0));
		
		jTextField2.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyTyped(java.awt.event.KeyEvent evt) {
				jTextField2jTextFieldkeyTyped(evt);
			}
		});

		jTextField3.setFont(new java.awt.Font("���Ŀ���", 0, 14));
		jTextField3.setForeground(new java.awt.Color(204, 204, 204));
		jTextField3.setText("\u8bf7\u8f93\u5165\u9a8c\u8bc1\u7801");
		jTextField3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
		jTextField3.setMargin(new java.awt.Insets(0, 0, 0, 0));
		
		jTextField3.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyTyped(java.awt.event.KeyEvent evt) {
				jTextField3jTextFieldkeyTyped(evt);
			}
		});

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout
				.setHorizontalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addGroup(
																								jPanel1Layout
																										.createSequentialGroup()
																										.addComponent(
																												jLabel2)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addComponent(
																												jTextField2,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												284,
																												Short.MAX_VALUE))
																						.addGroup(
																								jPanel1Layout
																										.createSequentialGroup()
																										.addComponent(
																												jLabel3)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addComponent(
																												jTextField3,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												137,
																												javax.swing.GroupLayout.PREFERRED_SIZE)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addComponent(
																												jButton1,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												131,
																												javax.swing.GroupLayout.PREFERRED_SIZE)))
																		.addContainerGap(
																				27,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(
																javax.swing.GroupLayout.Alignment.TRAILING,
																jPanel1Layout
																		.createSequentialGroup()
																		.addComponent(
																				jButton2,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				217,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addGap(
																				72,
																				72,
																				72))
														.addGroup(
																javax.swing.GroupLayout.Alignment.TRAILING,
																jPanel1Layout
																		.createSequentialGroup()
																		.addComponent(
																				jButton3,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				40,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addContainerGap())
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addComponent(
																				jLabel1)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
																		.addComponent(
																				jTextField1,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				286,
																				Short.MAX_VALUE)
																		.addGap(
																				27,
																				27,
																				27)))));
		jPanel1Layout
				.setVerticalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel1Layout
										.createSequentialGroup()
										.addGap(46, 46, 46)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel1)
														.addComponent(
																jTextField1,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																37,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGap(18, 18, 18)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel2)
														.addComponent(
																jTextField2,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																37,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGap(25, 25, 25)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel3)
														.addComponent(
																jTextField3,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																37,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																jButton1,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																36,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												33, Short.MAX_VALUE)
										.addComponent(jButton2)
										.addGap(23, 23, 23)
										.addComponent(
												jButton3,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												30,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addContainerGap()));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.PREFERRED_SIZE));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jTextField2jTextFieldkeyTyped(java.awt.event.KeyEvent evt) {
		if (this.jTextField2.getText().equals("����������")) {
			this.jTextField2.setText("");
		}
	}

	private void jTextField1jTextFieldkeyTyped(java.awt.event.KeyEvent evt) {
		if (this.jTextField1.getText().equals("������������")) {
			this.jTextField1.setText("");
		}
	}

	private void jTextField3jTextFieldkeyTyped(java.awt.event.KeyEvent evt) {
		if (this.jTextField3.getText().equals("��������֤��")) {
			this.jTextField3.setText("");
		}
	}

	private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {

		new ChooseWay().setVisible(true);
		this.dispose();

	}

	private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {
		//JOptionPane.showMessageDialog(this, "������");
		new LoginView1().setVisible(true);
		this.dispose();
	}

	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
		if (this.jButton1.getText().equals("��ȡ������֤��")) {
			JOptionPane.showMessageDialog(this, "���������ѷ�����������䣬��ע����գ�");
			this.dispose();
			new Forget().setVisible(true);
			this.dispose();
		}
	}

	private void jButton1MouseEntered(java.awt.event.MouseEvent evt) {
		this.jButton1.setBackground(Color.LIGHT_GRAY);
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		try {
			org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.launchBeautyEyeLNF();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new Forget().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton2;
	private javax.swing.JButton jButton3;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JTextField jTextField1;
	private javax.swing.JTextField jTextField2;
	private javax.swing.JTextField jTextField3;
	// End of variables declaration//GEN-END:variables

}