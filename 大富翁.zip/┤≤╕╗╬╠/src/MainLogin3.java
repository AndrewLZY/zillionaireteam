import java.awt.Dimension;
import java.awt.Toolkit;
import java.util.Random;

import javax.swing.ImageIcon;

/*
 * MainLogin3.java
 *
 * Created on __DATE__, __TIME__
 */

/**
 *
 * @author  __USER__
 */
public class MainLogin3 extends javax.swing.JFrame {

	/** Creates new form MainLogin3 */
	public MainLogin3() {
		initComponents();
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {
		
		//��������λ�ã�ʹ�Ի������   
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();   
        this.setLocation( (int) (screenSize.width - 1260) / 2 + 50,   
                        (int) (screenSize.height - 1100) / 2 + 150);   
        this.setResizable(false);

		jPanel1 = new javax.swing.JPanel();
		jPanel2 = new javax.swing.JPanel();
		jLabel1 = new javax.swing.JLabel();
		jLabel2 = new javax.swing.JLabel();
		jLabel3 = new javax.swing.JLabel();
		jLabel4 = new javax.swing.JLabel();
		jLabel5 = new javax.swing.JLabel();
		jLabel6 = new javax.swing.JLabel();
		jLabel7 = new javax.swing.JLabel();
		jLabel8 = new javax.swing.JLabel();
		jLabel9 = new javax.swing.JLabel();
		jLabel10 = new javax.swing.JLabel();
		jLabel11 = new javax.swing.JLabel();
		jLabel12 = new javax.swing.JLabel();
		jLabel13 = new javax.swing.JLabel();
		jLabel14 = new javax.swing.JLabel();
		jLabel15 = new javax.swing.JLabel();
		jLabel16 = new javax.swing.JLabel();
		jLabel17 = new javax.swing.JLabel();
		jLabel18 = new javax.swing.JLabel();
		jLabel19 = new javax.swing.JLabel();
		jLabel20 = new javax.swing.JLabel();
		jLabel21 = new javax.swing.JLabel();
		jLabel22 = new javax.swing.JLabel();
		jLabel23 = new javax.swing.JLabel();
		jLabel24 = new javax.swing.JLabel();
		jLabel25 = new javax.swing.JLabel();
		jLabel26 = new javax.swing.JLabel();
		jLabel27 = new javax.swing.JLabel();
		jLabel28 = new javax.swing.JLabel();
		jLabel29 = new javax.swing.JLabel();
		jLabel30 = new javax.swing.JLabel();
		jLabel31 = new javax.swing.JLabel();
		jLabel32 = new javax.swing.JLabel();
		jLabel33 = new javax.swing.JLabel();
		jLabel34 = new javax.swing.JLabel();
		jLabel35 = new javax.swing.JLabel();
		jLabel36 = new javax.swing.JLabel();
		jLabel37 = new javax.swing.JLabel();
		jLabel38 = new javax.swing.JLabel();
		jLabel39 = new javax.swing.JLabel();
		jLabel40 = new javax.swing.JLabel();
		jTextField5 = new javax.swing.JTextField();
		jTextField6 = new javax.swing.JTextField();
		jTextField7 = new javax.swing.JTextField();
		jButton9 = new javax.swing.JButton();
		jLabel41 = new javax.swing.JLabel();
		jLabel42 = new javax.swing.JLabel();
		jLabel43 = new javax.swing.JLabel();
		jLabel44 = new javax.swing.JLabel();
		jLabel45 = new javax.swing.JLabel();
		jLabel46 = new javax.swing.JLabel();
		jTextField1 = new javax.swing.JTextField();
		jLabel47 = new javax.swing.JLabel();
		jTextField2 = new javax.swing.JTextField();
		jLabel48 = new javax.swing.JLabel();
		jTextField3 = new javax.swing.JTextField();
		jLabel49 = new javax.swing.JLabel();
		jButton10 = new javax.swing.JButton();
		jButton11 = new javax.swing.JButton();
		jButton12 = new javax.swing.JButton();
		jButton13 = new javax.swing.JButton();
		jButton14 = new javax.swing.JButton();
		jButton15 = new javax.swing.JButton();
		jButton16 = new javax.swing.JButton();
		jButton17 = new javax.swing.JButton();
		jButton18 = new javax.swing.JButton();
		jButton19 = new javax.swing.JButton();
		jButton2 = new javax.swing.JButton();
		jButton3 = new javax.swing.JButton();
		jButton5 = new javax.swing.JButton();
		jButton4 = new javax.swing.JButton();
		jButton7 = new javax.swing.JButton();
		jButton1 = new javax.swing.JButton();
		jButton6 = new javax.swing.JButton();
		jButton8 = new javax.swing.JButton();
		jButton23 = new javax.swing.JButton();
		jTextField4 = new javax.swing.JTextField();
		jScrollPane1 = new javax.swing.JScrollPane();
		jTextArea1 = new javax.swing.JTextArea();
		jLabel50 = new javax.swing.JLabel();
		jButton20 = new javax.swing.JButton();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jPanel1.setBackground(new java.awt.Color(255, 255, 255));

		jPanel2.setBackground(new java.awt.Color(255, 255, 255));

		jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/���.jpg"))); // NOI18N
		jLabel1.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel2.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel3.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel4.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/ҽԺ.jpg"))); // NOI18N
		jLabel5.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel6.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/���.jpg"))); // NOI18N
		jLabel7.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel8.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel9.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/����.jpg"))); // NOI18N
		jLabel10.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel11.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel12.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/��Ʒ.jpg"))); // NOI18N
		jLabel13.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel14.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel15.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/����.jpg"))); // NOI18N
		jLabel16.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel17.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel18.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/���.jpg"))); // NOI18N
		jLabel19.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel20.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/��Ʒ.jpg"))); // NOI18N
		jLabel21.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel22.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel22.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel23.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/����.jpg"))); // NOI18N
		jLabel23.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel24.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel24.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel25.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel25.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/����.jpg"))); // NOI18N
		jLabel26.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel27.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel27.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel28.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel28.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel29.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/ħ��.jpg"))); // NOI18N
		jLabel29.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel30.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel30.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel31.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel31.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel32.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel32.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel33.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/���.jpg"))); // NOI18N
		jLabel33.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel34.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel34.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel35.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel35.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel36.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel36.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel37.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel37.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel38.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/ҽԺ.jpg"))); // NOI18N
		jLabel38.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel39.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel39.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel40.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel40.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jTextField5.setFont(new java.awt.Font("���Ŀ���", 1, 30));
		jTextField5.setText("\u4e09");
		jTextField5.setBorder(null);
		jTextField5.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jTextField5ActionPerformed(evt);
			}
		});

		jTextField6.setFont(new java.awt.Font("���Ŀ���", 1, 30));
		jTextField6.setText("\u5173");
		jTextField6.setBorder(null);

		jTextField7.setFont(new java.awt.Font("���Ŀ���", 1, 30));
		jTextField7.setText("\u5361");
		jTextField7.setBorder(null);

		javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(
				jPanel2);
		jPanel2.setLayout(jPanel2Layout);
		jPanel2Layout
				.setHorizontalGroup(jPanel2Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel2Layout
										.createSequentialGroup()
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGap(
																				269,
																				269,
																				269)
																		.addComponent(
																				jTextField5,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGap(
																				235,
																				235,
																				235)
																		.addComponent(
																				jTextField7,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGap(
																				204,
																				204,
																				204)
																		.addComponent(
																				jTextField6,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE)))
										.addContainerGap(321, Short.MAX_VALUE))
						.addGroup(
								jPanel2Layout
										.createParallelGroup(
												javax.swing.GroupLayout.Alignment.LEADING)
										.addGroup(
												jPanel2Layout
														.createSequentialGroup()
														.addGap(49, 49, 49)
														.addGroup(
																jPanel2Layout
																		.createParallelGroup(
																				javax.swing.GroupLayout.Alignment.LEADING)
																		.addGroup(
																				javax.swing.GroupLayout.Alignment.TRAILING,
																				jPanel2Layout
																						.createSequentialGroup()
																						.addGroup(
																								jPanel2Layout
																										.createParallelGroup(
																												javax.swing.GroupLayout.Alignment.LEADING)
																										.addGroup(
																												jPanel2Layout
																														.createSequentialGroup()
																														.addComponent(
																																jLabel32)
																														.addPreferredGap(
																																javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																																javax.swing.GroupLayout.DEFAULT_SIZE,
																																Short.MAX_VALUE)
																														.addComponent(
																																jLabel31)
																														.addPreferredGap(
																																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																														.addComponent(
																																jLabel30))
																										.addGroup(
																												jPanel2Layout
																														.createSequentialGroup()
																														.addGroup(
																																jPanel2Layout
																																		.createParallelGroup(
																																				javax.swing.GroupLayout.Alignment.LEADING)
																																		.addComponent(
																																				jLabel34)
																																		.addComponent(
																																				jLabel38))
																														.addPreferredGap(
																																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																														.addGroup(
																																jPanel2Layout
																																		.createParallelGroup(
																																				javax.swing.GroupLayout.Alignment.LEADING)
																																		.addComponent(
																																				jLabel36)
																																		.addComponent(
																																				jLabel35)
																																		.addComponent(
																																				jLabel37)))
																										.addComponent(
																												jLabel39))
																						.addPreferredGap(
																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																						.addGroup(
																								jPanel2Layout
																										.createParallelGroup(
																												javax.swing.GroupLayout.Alignment.LEADING)
																										.addComponent(
																												jLabel29)
																										.addGroup(
																												jPanel2Layout
																														.createSequentialGroup()
																														.addComponent(
																																jLabel28)
																														.addPreferredGap(
																																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																														.addComponent(
																																jLabel27)
																														.addPreferredGap(
																																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																														.addGroup(
																																jPanel2Layout
																																		.createParallelGroup(
																																				javax.swing.GroupLayout.Alignment.LEADING)
																																		.addComponent(
																																				jLabel15)
																																		.addGroup(
																																				jPanel2Layout
																																						.createSequentialGroup()
																																						.addComponent(
																																								jLabel14)
																																						.addPreferredGap(
																																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																						.addComponent(
																																								jLabel13)
																																						.addPreferredGap(
																																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																						.addComponent(
																																								jLabel12))
																																		.addComponent(
																																				jLabel16)
																																		.addGroup(
																																				jPanel2Layout
																																						.createParallelGroup(
																																								javax.swing.GroupLayout.Alignment.TRAILING)
																																						.addGroup(
																																								jPanel2Layout
																																										.createSequentialGroup()
																																										.addComponent(
																																												jLabel26)
																																										.addPreferredGap(
																																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																										.addComponent(
																																												jLabel25)
																																										.addPreferredGap(
																																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																										.addComponent(
																																												jLabel24))
																																						.addGroup(
																																								jPanel2Layout
																																										.createSequentialGroup()
																																										.addComponent(
																																												jLabel17)
																																										.addPreferredGap(
																																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																										.addComponent(
																																												jLabel18)
																																										.addPreferredGap(
																																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																										.addComponent(
																																												jLabel19)))))))
																		.addComponent(
																				jLabel33)
																		.addGroup(
																				javax.swing.GroupLayout.Alignment.TRAILING,
																				jPanel2Layout
																						.createSequentialGroup()
																						.addGroup(
																								jPanel2Layout
																										.createParallelGroup(
																												javax.swing.GroupLayout.Alignment.TRAILING,
																												false)
																										.addGroup(
																												javax.swing.GroupLayout.Alignment.LEADING,
																												jPanel2Layout
																														.createSequentialGroup()
																														.addComponent(
																																jLabel40)
																														.addGap(
																																118,
																																118,
																																118))
																										.addGroup(
																												jPanel2Layout
																														.createSequentialGroup()
																														.addComponent(
																																jLabel1)
																														.addPreferredGap(
																																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																														.addComponent(
																																jLabel2)
																														.addPreferredGap(
																																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																														.addComponent(
																																jLabel3)))
																						.addPreferredGap(
																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																						.addComponent(
																								jLabel4)
																						.addPreferredGap(
																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																						.addComponent(
																								jLabel5)
																						.addPreferredGap(
																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																						.addComponent(
																								jLabel6)
																						.addPreferredGap(
																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																						.addComponent(
																								jLabel7)
																						.addPreferredGap(
																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																						.addComponent(
																								jLabel8)))
														.addPreferredGap(
																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
														.addGroup(
																jPanel2Layout
																		.createParallelGroup(
																				javax.swing.GroupLayout.Alignment.LEADING)
																		.addComponent(
																				jLabel9)
																		.addComponent(
																				jLabel10)
																		.addComponent(
																				jLabel11)
																		.addComponent(
																				jLabel20)
																		.addComponent(
																				jLabel21)
																		.addComponent(
																				jLabel23)
																		.addComponent(
																				jLabel22))
														.addGap(49, 49, 49))));
		jPanel2Layout
				.setVerticalGroup(jPanel2Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel2Layout
										.createSequentialGroup()
										.addGap(177, 177, 177)
										.addComponent(
												jTextField6,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(27, 27, 27)
										.addComponent(
												jTextField7,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(23, 23, 23)
										.addComponent(
												jTextField5,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addContainerGap(214, Short.MAX_VALUE))
						.addGroup(
								jPanel2Layout
										.createParallelGroup(
												javax.swing.GroupLayout.Alignment.LEADING)
										.addGroup(
												jPanel2Layout
														.createSequentialGroup()
														.addGap(14, 14, 14)
														.addGroup(
																jPanel2Layout
																		.createParallelGroup(
																				javax.swing.GroupLayout.Alignment.LEADING)
																		.addComponent(
																				jLabel9)
																		.addComponent(
																				jLabel8)
																		.addComponent(
																				jLabel7)
																		.addComponent(
																				jLabel6)
																		.addComponent(
																				jLabel5)
																		.addComponent(
																				jLabel4)
																		.addComponent(
																				jLabel3)
																		.addComponent(
																				jLabel2)
																		.addComponent(
																				jLabel1))
														.addGroup(
																jPanel2Layout
																		.createParallelGroup(
																				javax.swing.GroupLayout.Alignment.TRAILING)
																		.addGroup(
																				javax.swing.GroupLayout.Alignment.LEADING,
																				jPanel2Layout
																						.createSequentialGroup()
																						.addPreferredGap(
																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																						.addGroup(
																								jPanel2Layout
																										.createParallelGroup(
																												javax.swing.GroupLayout.Alignment.TRAILING)
																										.addGroup(
																												jPanel2Layout
																														.createSequentialGroup()
																														.addComponent(
																																jLabel40)
																														.addPreferredGap(
																																javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																																javax.swing.GroupLayout.DEFAULT_SIZE,
																																Short.MAX_VALUE)
																														.addComponent(
																																jLabel39)
																														.addPreferredGap(
																																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																														.addGroup(
																																jPanel2Layout
																																		.createParallelGroup(
																																				javax.swing.GroupLayout.Alignment.TRAILING)
																																		.addComponent(
																																				jLabel38)
																																		.addComponent(
																																				jLabel37))
																														.addPreferredGap(
																																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																														.addComponent(
																																jLabel36)
																														.addPreferredGap(
																																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																														.addGroup(
																																jPanel2Layout
																																		.createParallelGroup(
																																				javax.swing.GroupLayout.Alignment.LEADING)
																																		.addGroup(
																																				jPanel2Layout
																																						.createSequentialGroup()
																																						.addComponent(
																																								jLabel34)
																																						.addPreferredGap(
																																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																						.addComponent(
																																								jLabel33))
																																		.addComponent(
																																				jLabel35))
																														.addPreferredGap(
																																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																														.addGroup(
																																jPanel2Layout
																																		.createParallelGroup(
																																				javax.swing.GroupLayout.Alignment.LEADING)
																																		.addComponent(
																																				jLabel30)
																																		.addGroup(
																																				jPanel2Layout
																																						.createSequentialGroup()
																																						.addComponent(
																																								jLabel29)
																																						.addPreferredGap(
																																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																						.addComponent(
																																								jLabel28))
																																		.addComponent(
																																				jLabel31)
																																		.addComponent(
																																				jLabel32)))
																										.addGroup(
																												jPanel2Layout
																														.createSequentialGroup()
																														.addComponent(
																																jLabel10)
																														.addPreferredGap(
																																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																														.addGroup(
																																jPanel2Layout
																																		.createParallelGroup(
																																				javax.swing.GroupLayout.Alignment.LEADING)
																																		.addComponent(
																																				jLabel11)
																																		.addComponent(
																																				jLabel12)
																																		.addComponent(
																																				jLabel13)
																																		.addComponent(
																																				jLabel14))
																														.addPreferredGap(
																																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																														.addComponent(
																																jLabel15)
																														.addPreferredGap(
																																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																														.addComponent(
																																jLabel16)
																														.addPreferredGap(
																																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																														.addGroup(
																																jPanel2Layout
																																		.createParallelGroup(
																																				javax.swing.GroupLayout.Alignment.LEADING)
																																		.addComponent(
																																				jLabel17)
																																		.addComponent(
																																				jLabel18)
																																		.addComponent(
																																				jLabel19)
																																		.addComponent(
																																				jLabel20))
																														.addPreferredGap(
																																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																														.addGroup(
																																jPanel2Layout
																																		.createParallelGroup(
																																				javax.swing.GroupLayout.Alignment.TRAILING)
																																		.addComponent(
																																				jLabel24)
																																		.addComponent(
																																				jLabel25)
																																		.addComponent(
																																				jLabel26)
																																		.addGroup(
																																				jPanel2Layout
																																						.createSequentialGroup()
																																						.addComponent(
																																								jLabel21)
																																						.addPreferredGap(
																																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																						.addComponent(
																																								jLabel22)
																																						.addPreferredGap(
																																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																						.addComponent(
																																								jLabel23))))))
																		.addGroup(
																				jPanel2Layout
																						.createSequentialGroup()
																						.addGap(
																								428,
																								428,
																								428)
																						.addComponent(
																								jLabel27)))
														.addGap(15, 15, 15))));

		jButton9.setBackground(new java.awt.Color(255, 255, 255));
		jButton9.setBorder(null);
		jButton9.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton9ActionPerformed(evt);
			}
		});

		jLabel41.setBackground(new java.awt.Color(255, 255, 255));
		jLabel41.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jLabel41.setText("\u8bf7\u9009\u62e9\u89d2\u8272\uff1a");

		jLabel42.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�𱴱�.jpg"))); // NOI18N
		jLabel42.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel43.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/��С��.jpg"))); // NOI18N
		jLabel43.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel44.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/������.jpg"))); // NOI18N
		jLabel44.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel45.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/ɳ¡��˹.jpg"))); // NOI18N
		jLabel45.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel46.setBackground(new java.awt.Color(255, 255, 255));
		jLabel46.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jLabel46.setText("\u6211\u7684\u8d44\u91d1\uff1a");

		jTextField1.setText("  \uffe52,500  ");

		jLabel47.setBackground(new java.awt.Color(255, 255, 255));
		jLabel47.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jLabel47.setText("\u5361\u70b9\u6570\uff1a");

		jTextField2.setText("    200   ");

		jLabel48.setBackground(new java.awt.Color(255, 255, 255));
		jLabel48.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jLabel48.setText("\u623f\u5b50\uff1a");

		jLabel49.setBackground(new java.awt.Color(255, 255, 255));
		jLabel49.setFont(new java.awt.Font("���Ŀ���", 1, 16));
		jLabel49
				.setText("\u4ee5\u4e0b\u663e\u793a\u7eff\u8272\u7684\u4e3a\u53ef\u7528\u5361\u724c\uff1a");

		jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/ͣ������С��.jpg"))); // NOI18N

		jButton11.setBackground(new java.awt.Color(204, 255, 204));
		jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/ͣ������С��.jpg"))); // NOI18N

		jButton12.setBackground(new java.awt.Color(204, 255, 204));
		jButton12.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/·�Ͽ���С��.jpg"))); // NOI18N

		jButton13.setBackground(new java.awt.Color(204, 255, 204));
		jButton13.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/���ݽ�������С��.jpg"))); // NOI18N

		jButton14.setBackground(new java.awt.Color(204, 255, 204));
		jButton14.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�������޿���С��.jpg"))); // NOI18N

		jButton15.setBackground(new java.awt.Color(204, 255, 204));
		jButton15.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/���񿨣�С��.jpg"))); // NOI18N
		jButton15.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton15ActionPerformed(evt);
			}
		});

		jButton16.setBackground(new java.awt.Color(204, 255, 204));
		jButton16.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/������������С��.jpg"))); // NOI18N

		jButton17.setBackground(new java.awt.Color(204, 255, 204));
		jButton17.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/ը������С��.jpg"))); // NOI18N

		jButton18.setBackground(new java.awt.Color(204, 255, 204));
		jButton18.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/���ʿ���С��.jpg"))); // NOI18N

		jButton19.setBackground(new java.awt.Color(204, 255, 204));
		jButton19.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/˥�񿨣�С��.jpg"))); // NOI18N

		jButton2.setBackground(new java.awt.Color(255, 255, 255));
		jButton2.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jButton2.setText("\u6e38\u620f\u89c4\u5219");
		jButton2.setBorder(null);
		jButton2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton2ActionPerformed(evt);
			}
		});

		jButton3.setBackground(new java.awt.Color(255, 255, 255));
		jButton3.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jButton3.setText("\u89d2\u8272\u4ecb\u7ecd");
		jButton3.setBorder(null);
		jButton3.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton3ActionPerformed(evt);
			}
		});

		jButton5.setBackground(new java.awt.Color(255, 255, 255));
		jButton5.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jButton5.setText("\u5173\u5361\u8bb0\u5f55");
		jButton5.setBorder(null);
		jButton5.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton5ActionPerformed(evt);
			}
		});

		jButton4.setBackground(new java.awt.Color(255, 255, 255));
		jButton4.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jButton4.setText("\u9053\u5177\u4f7f\u7528");
		jButton4.setBorder(null);
		jButton4.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton4ActionPerformed(evt);
			}
		});

		jButton7.setBackground(new java.awt.Color(255, 255, 255));
		jButton7.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jButton7.setText("\u58f0\u97f3");
		jButton7.setBorder(null);
		jButton7.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton7ActionPerformed(evt);
			}
		});

		jButton1.setBackground(new java.awt.Color(255, 255, 255));
		jButton1.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jButton1.setText("\u6211\u7684\u8d44\u6599");
		jButton1.setBorder(null);
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton1ActionPerformed(evt);
			}
		});

		jButton6.setBackground(new java.awt.Color(255, 255, 255));
		jButton6.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jButton6.setText("\u6392\u884c\u699c");
		jButton6.setBorder(null);
		jButton6.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton6ActionPerformed(evt);
			}
		});

		jButton8.setBackground(new java.awt.Color(255, 255, 255));
		jButton8.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jButton8.setText("\u767b\u5f55");
		jButton8.setBorder(null);
		jButton8.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton8ActionPerformed(evt);
			}
		});

		jButton23.setBackground(new java.awt.Color(255, 255, 255));
		jButton23.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jButton23.setText("\u8fd4\u56de");
		jButton23.setBorder(null);
		jButton23.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton23ActionPerformed(evt);
			}
		});

		jTextArea1.setColumns(20);
		jTextArea1.setRows(5);
		jScrollPane1.setViewportView(jTextArea1);

		jLabel50.setBackground(new java.awt.Color(255, 255, 255));
		jLabel50.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jLabel50.setText("\u5feb\u6377\u804a\u5929\u7a97\u53e3\uff1a");

		jButton20.setBackground(new java.awt.Color(255, 255, 255));
		jButton20.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jButton20.setText("\u53d1\u9001");
		jButton20.setBorder(null);

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout
				.setHorizontalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addGap(
																				23,
																				23,
																				23)
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jLabel41)
																						.addGroup(
																								jPanel1Layout
																										.createSequentialGroup()
																										.addGap(
																												5,
																												5,
																												5)
																										.addGroup(
																												jPanel1Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.TRAILING)
																														.addComponent(
																																jLabel42)
																														.addGroup(
																																jPanel1Layout
																																		.createSequentialGroup()
																																		.addComponent(
																																				jButton10,
																																				javax.swing.GroupLayout.PREFERRED_SIZE,
																																				0,
																																				javax.swing.GroupLayout.PREFERRED_SIZE)
																																		.addPreferredGap(
																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																		.addComponent(
																																				jLabel44)))
																										.addGap(
																												18,
																												18,
																												18)
																										.addGroup(
																												jPanel1Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.LEADING)
																														.addComponent(
																																jLabel45)
																														.addComponent(
																																jLabel43)))
																						.addGroup(
																								jPanel1Layout
																										.createSequentialGroup()
																										.addComponent(
																												jButton1)
																										.addGap(
																												18,
																												18,
																												18)
																										.addComponent(
																												jButton2))))
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addComponent(
																				jButton11,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				60,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton12,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				60,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton13,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				60,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addComponent(
																				jButton14,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				60,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton15,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				60,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton16,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				60,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addComponent(
																				jButton17,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				60,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton18,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				60,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton19,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				60,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addComponent(jLabel49))
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addGap(
																				5,
																				5,
																				5)
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addGroup(
																								jPanel1Layout
																										.createSequentialGroup()
																										.addComponent(
																												jButton3)
																										.addGap(
																												18,
																												18,
																												18)
																										.addComponent(
																												jButton4)
																										.addGap(
																												18,
																												18,
																												18)
																										.addComponent(
																												jButton5)
																										.addGap(
																												18,
																												18,
																												18)
																										.addComponent(
																												jButton6)
																										.addGap(
																												18,
																												18,
																												18)
																										.addComponent(
																												jButton7))
																						.addComponent(
																								jPanel2,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								javax.swing.GroupLayout.PREFERRED_SIZE))
																		.addGap(
																				13,
																				13,
																				13)
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addGroup(
																								jPanel1Layout
																										.createSequentialGroup()
																										.addGap(
																												22,
																												22,
																												22)
																										.addComponent(
																												jButton9,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												97,
																												javax.swing.GroupLayout.PREFERRED_SIZE))
																						.addGroup(
																								jPanel1Layout
																										.createSequentialGroup()
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addGroup(
																												jPanel1Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.LEADING)
																														.addGroup(
																																jPanel1Layout
																																		.createSequentialGroup()
																																		.addGap(
																																				12,
																																				12,
																																				12)
																																		.addComponent(
																																				jLabel50))
																														.addComponent(
																																jButton20,
																																javax.swing.GroupLayout.Alignment.TRAILING)
																														.addGroup(
																																jPanel1Layout
																																		.createParallelGroup(
																																				javax.swing.GroupLayout.Alignment.TRAILING,
																																				false)
																																		.addComponent(
																																				jTextField4,
																																				javax.swing.GroupLayout.Alignment.LEADING)
																																		.addComponent(
																																				jScrollPane1,
																																				javax.swing.GroupLayout.Alignment.LEADING,
																																				javax.swing.GroupLayout.PREFERRED_SIZE,
																																				233,
																																				javax.swing.GroupLayout.PREFERRED_SIZE)
																																		.addGroup(
																																				jPanel1Layout
																																						.createSequentialGroup()
																																						.addComponent(
																																								jButton8)
																																						.addGap(
																																								22,
																																								22,
																																								22)
																																						.addComponent(
																																								jButton23)))))))
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addGap(
																				66,
																				66,
																				66)
																		.addComponent(
																				jLabel46)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jTextField1,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addGap(
																				49,
																				49,
																				49)
																		.addComponent(
																				jLabel47)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jTextField2,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addGap(
																				57,
																				57,
																				57)
																		.addComponent(
																				jLabel48)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jTextField3,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)))
										.addContainerGap(33, Short.MAX_VALUE)));
		jPanel1Layout
				.setVerticalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel1Layout
																		.createParallelGroup(
																				javax.swing.GroupLayout.Alignment.BASELINE)
																		.addComponent(
																				jButton3)
																		.addComponent(
																				jButton4)
																		.addComponent(
																				jButton5)
																		.addComponent(
																				jButton6)
																		.addComponent(
																				jButton7)
																		.addComponent(
																				jButton1)
																		.addComponent(
																				jButton2))
														.addGroup(
																jPanel1Layout
																		.createParallelGroup(
																				javax.swing.GroupLayout.Alignment.BASELINE)
																		.addComponent(
																				jButton23)
																		.addComponent(
																				jButton8)))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addGroup(
																								jPanel1Layout
																										.createSequentialGroup()
																										.addGap(
																												84,
																												84,
																												84)
																										.addComponent(
																												jLabel41)
																										.addGap(
																												29,
																												29,
																												29)
																										.addGroup(
																												jPanel1Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.LEADING)
																														.addComponent(
																																jLabel42)
																														.addComponent(
																																jLabel43))
																										.addGap(
																												12,
																												12,
																												12)
																										.addGroup(
																												jPanel1Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.LEADING)
																														.addGroup(
																																jPanel1Layout
																																		.createSequentialGroup()
																																		.addGap(
																																				40,
																																				40,
																																				40)
																																		.addComponent(
																																				jButton10,
																																				javax.swing.GroupLayout.DEFAULT_SIZE,
																																				javax.swing.GroupLayout.DEFAULT_SIZE,
																																				Short.MAX_VALUE)
																																		.addPreferredGap(
																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED))
																														.addGroup(
																																jPanel1Layout
																																		.createSequentialGroup()
																																		.addGap(
																																				2,
																																				2,
																																				2)
																																		.addGroup(
																																				jPanel1Layout
																																						.createParallelGroup(
																																								javax.swing.GroupLayout.Alignment.LEADING)
																																						.addComponent(
																																								jLabel44)
																																						.addComponent(
																																								jLabel45))
																																		.addGap(
																																				34,
																																				34,
																																				34)))
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addComponent(
																												jLabel49)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addGroup(
																												jPanel1Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.LEADING)
																														.addComponent(
																																jButton11)
																														.addComponent(
																																jButton12)
																														.addComponent(
																																jButton13))
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addGroup(
																												jPanel1Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.LEADING)
																														.addComponent(
																																jButton16)
																														.addComponent(
																																jButton15)
																														.addGroup(
																																jPanel1Layout
																																		.createSequentialGroup()
																																		.addComponent(
																																				jButton14)
																																		.addPreferredGap(
																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																		.addGroup(
																																				jPanel1Layout
																																						.createParallelGroup(
																																								javax.swing.GroupLayout.Alignment.LEADING)
																																						.addComponent(
																																								jButton18)
																																						.addComponent(
																																								jButton17)
																																						.addComponent(
																																								jButton19))))
																										.addGap(
																												107,
																												107,
																												107))
																						.addGroup(
																								jPanel1Layout
																										.createSequentialGroup()
																										.addGap(
																												54,
																												54,
																												54)
																										.addComponent(
																												jPanel2,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												javax.swing.GroupLayout.PREFERRED_SIZE)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
																										.addGroup(
																												jPanel1Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.BASELINE)
																														.addComponent(
																																jLabel46)
																														.addComponent(
																																jTextField1,
																																javax.swing.GroupLayout.PREFERRED_SIZE,
																																javax.swing.GroupLayout.DEFAULT_SIZE,
																																javax.swing.GroupLayout.PREFERRED_SIZE)
																														.addComponent(
																																jLabel47)
																														.addComponent(
																																jTextField2,
																																javax.swing.GroupLayout.PREFERRED_SIZE,
																																javax.swing.GroupLayout.DEFAULT_SIZE,
																																javax.swing.GroupLayout.PREFERRED_SIZE)
																														.addComponent(
																																jLabel48)
																														.addComponent(
																																jTextField3,
																																javax.swing.GroupLayout.PREFERRED_SIZE,
																																javax.swing.GroupLayout.DEFAULT_SIZE,
																																javax.swing.GroupLayout.PREFERRED_SIZE))))
																		.addGap(
																				493,
																				493,
																				493))
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addGap(
																				87,
																				87,
																				87)
																		.addComponent(
																				jLabel50)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jScrollPane1,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				262,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jTextField4,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton20)
																		.addGap(
																				69,
																				69,
																				69)
																		.addComponent(
																				jButton9,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				94,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addContainerGap()))));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.PREFERRED_SIZE));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 714,
				javax.swing.GroupLayout.PREFERRED_SIZE));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jButton23ActionPerformed(java.awt.event.ActionEvent evt) {
		new ChooseWay().setVisible(true);
		this.dispose();
	}

	private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {
		new LoginView().setVisible(true);
		this.dispose();
	}

	private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {
		new Ranking().setVisible(true);
		this.dispose();
	}

	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
		new data().setVisible(true);
		this.dispose();
	}

	private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {
		new Cards().setVisible(true);
		this.dispose();
	}

	private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {
		new Record().setVisible(true);
		this.dispose();
	}

	private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {
		new Role().setVisible(true);
		this.dispose();
	}

	private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
		new Rule().setVisible(true);
		this.dispose();
	}

	private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {
		Random r = new Random();
		int n = r.nextInt() % 6 + 1;
		System.out.println(n);
		this.jButton9.setIcon(new ImageIcon("img/" + n + ".jpg"));
	}

	private void jTextField5ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		try {
			org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.launchBeautyEyeLNF();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new MainLogin3().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton10;
	private javax.swing.JButton jButton11;
	private javax.swing.JButton jButton12;
	private javax.swing.JButton jButton13;
	private javax.swing.JButton jButton14;
	private javax.swing.JButton jButton15;
	private javax.swing.JButton jButton16;
	private javax.swing.JButton jButton17;
	private javax.swing.JButton jButton18;
	private javax.swing.JButton jButton19;
	private javax.swing.JButton jButton2;
	private javax.swing.JButton jButton20;
	private javax.swing.JButton jButton23;
	private javax.swing.JButton jButton3;
	private javax.swing.JButton jButton4;
	private javax.swing.JButton jButton5;
	private javax.swing.JButton jButton6;
	private javax.swing.JButton jButton7;
	private javax.swing.JButton jButton8;
	private javax.swing.JButton jButton9;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel10;
	private javax.swing.JLabel jLabel11;
	private javax.swing.JLabel jLabel12;
	private javax.swing.JLabel jLabel13;
	private javax.swing.JLabel jLabel14;
	private javax.swing.JLabel jLabel15;
	private javax.swing.JLabel jLabel16;
	private javax.swing.JLabel jLabel17;
	private javax.swing.JLabel jLabel18;
	private javax.swing.JLabel jLabel19;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel20;
	private javax.swing.JLabel jLabel21;
	private javax.swing.JLabel jLabel22;
	private javax.swing.JLabel jLabel23;
	private javax.swing.JLabel jLabel24;
	private javax.swing.JLabel jLabel25;
	private javax.swing.JLabel jLabel26;
	private javax.swing.JLabel jLabel27;
	private javax.swing.JLabel jLabel28;
	private javax.swing.JLabel jLabel29;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel30;
	private javax.swing.JLabel jLabel31;
	private javax.swing.JLabel jLabel32;
	private javax.swing.JLabel jLabel33;
	private javax.swing.JLabel jLabel34;
	private javax.swing.JLabel jLabel35;
	private javax.swing.JLabel jLabel36;
	private javax.swing.JLabel jLabel37;
	private javax.swing.JLabel jLabel38;
	private javax.swing.JLabel jLabel39;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel40;
	private javax.swing.JLabel jLabel41;
	private javax.swing.JLabel jLabel42;
	private javax.swing.JLabel jLabel43;
	private javax.swing.JLabel jLabel44;
	private javax.swing.JLabel jLabel45;
	private javax.swing.JLabel jLabel46;
	private javax.swing.JLabel jLabel47;
	private javax.swing.JLabel jLabel48;
	private javax.swing.JLabel jLabel49;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JLabel jLabel50;
	private javax.swing.JLabel jLabel6;
	private javax.swing.JLabel jLabel7;
	private javax.swing.JLabel jLabel8;
	private javax.swing.JLabel jLabel9;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JTextArea jTextArea1;
	private javax.swing.JTextField jTextField1;
	private javax.swing.JTextField jTextField2;
	private javax.swing.JTextField jTextField3;
	private javax.swing.JTextField jTextField4;
	private javax.swing.JTextField jTextField5;
	private javax.swing.JTextField jTextField6;
	private javax.swing.JTextField jTextField7;
	// End of variables declaration//GEN-END:variables

}