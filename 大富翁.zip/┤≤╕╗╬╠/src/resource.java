//import java.awt.Graphics;
//import java.awt.Graphics2D;
//import java.awt.Image;
//import java.awt.Toolkit;
//import java.awt.event.MouseEvent;
//import java.awt.event.MouseListener;
//
//import javax.swing.JPanel;
//
//
//public class resource extends JPanel implements MouseListener {
//	Image bg;
//	private void paintComponent(Graphics g){
//		super.paintComponents(g);
////		Image bgImg = null;
////		try{
////			bgImg = Imagel0.read(new Fiel("D:/360Downloads/312670.jpg"));
////		}catch(IOException e){
////			e.printStackTrace();
////		}
////		arg0.drawImage(bgImg,0,0,null);
////	}
//		Graphics2D g2 = (Graphics2D)g;
//		bg = Toolkit.getDefaultToolkit().getImage("D:/360Downloads/312670.jpg");
//		g.drawImage(bg, 50, 0, null);
//		repaint();
//	}
//	public void mouseClicked(MouseEvent arg0){
//		
//	}
//    public void mouseEntered(MouseEvent arg0){
//		
//	}
//    public void mouseExited(MouseEvent arg0){
//		
//	}
//    public void mousePressed(MouseEvent arg0){
//		
//	}
//    public void mouseReleased(MouseEvent arg0){
//		
//	}
//
//	/**
//	 * @param args
//	 */
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	}
//
//}
