import java.awt.Dimension;
import java.awt.Toolkit;

/*
 * Map1.java
 *
 * Created on __DATE__, __TIME__
 */

/**
 *
 * @author  __USER__
 */
public class Map1 extends javax.swing.JFrame {

	/** Creates new form Map1 */
	public Map1() {
		initComponents();
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {
		
		//��������λ�ã�ʹ�Ի������   
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();   
        this.setLocation( (int) (screenSize.width - 1260) / 2 + 50,   
                        (int) (screenSize.height - 1000) / 2 + 150);   
        this.setResizable(false);

		jButton1 = new javax.swing.JButton();
		jPanel1 = new javax.swing.JPanel();
		jLabel1 = new javax.swing.JLabel();
		jLabel2 = new javax.swing.JLabel();
		jLabel3 = new javax.swing.JLabel();
		jLabel4 = new javax.swing.JLabel();
		jLabel5 = new javax.swing.JLabel();
		jLabel6 = new javax.swing.JLabel();
		jLabel7 = new javax.swing.JLabel();
		jLabel8 = new javax.swing.JLabel();
		jLabel9 = new javax.swing.JLabel();
		jLabel10 = new javax.swing.JLabel();
		jLabel11 = new javax.swing.JLabel();
		jLabel12 = new javax.swing.JLabel();
		jLabel13 = new javax.swing.JLabel();
		jLabel14 = new javax.swing.JLabel();
		jLabel15 = new javax.swing.JLabel();
		jLabel16 = new javax.swing.JLabel();
		jLabel17 = new javax.swing.JLabel();
		jLabel18 = new javax.swing.JLabel();
		jLabel19 = new javax.swing.JLabel();
		jLabel20 = new javax.swing.JLabel();
		jLabel21 = new javax.swing.JLabel();
		jLabel22 = new javax.swing.JLabel();
		jLabel23 = new javax.swing.JLabel();
		jLabel24 = new javax.swing.JLabel();
		jLabel25 = new javax.swing.JLabel();
		jLabel26 = new javax.swing.JLabel();
		jLabel27 = new javax.swing.JLabel();
		jLabel28 = new javax.swing.JLabel();
		jLabel29 = new javax.swing.JLabel();
		jLabel30 = new javax.swing.JLabel();
		jLabel31 = new javax.swing.JLabel();
		jLabel32 = new javax.swing.JLabel();
		jLabel33 = new javax.swing.JLabel();
		jLabel34 = new javax.swing.JLabel();
		jLabel35 = new javax.swing.JLabel();
		jLabel36 = new javax.swing.JLabel();
		jLabel37 = new javax.swing.JLabel();
		jLabel38 = new javax.swing.JLabel();
		jLabel39 = new javax.swing.JLabel();
		jLabel40 = new javax.swing.JLabel();
		jTextField1 = new javax.swing.JTextField();
		jTextField2 = new javax.swing.JTextField();
		jTextField3 = new javax.swing.JTextField();
		jPanel2 = new javax.swing.JPanel();
		jLabel43 = new javax.swing.JLabel();
		jLabel44 = new javax.swing.JLabel();
		jLabel45 = new javax.swing.JLabel();
		jLabel46 = new javax.swing.JLabel();
		jLabel47 = new javax.swing.JLabel();
		jLabel48 = new javax.swing.JLabel();
		jLabel49 = new javax.swing.JLabel();
		jLabel50 = new javax.swing.JLabel();
		jLabel51 = new javax.swing.JLabel();
		jLabel52 = new javax.swing.JLabel();
		jLabel53 = new javax.swing.JLabel();
		jLabel54 = new javax.swing.JLabel();
		jLabel55 = new javax.swing.JLabel();
		jButton2 = new javax.swing.JButton();

		jButton1.setText("jButton1");

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jPanel1.setBackground(new java.awt.Color(255, 255, 255));

		jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/���.jpg"))); // NOI18N
		jLabel1.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel2.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel3.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel4.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/ҽԺ.jpg"))); // NOI18N
		jLabel5.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel6.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/���.jpg"))); // NOI18N
		jLabel7.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel8.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel9.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/����.jpg"))); // NOI18N
		jLabel10.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel11.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel12.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/��Ʒ.jpg"))); // NOI18N
		jLabel13.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel14.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel15.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/����.jpg"))); // NOI18N
		jLabel16.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel17.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel18.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/���.jpg"))); // NOI18N
		jLabel19.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel20.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/��Ʒ.jpg"))); // NOI18N
		jLabel21.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel22.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel22.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel23.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/����.jpg"))); // NOI18N
		jLabel23.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel24.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel24.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel25.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel25.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/����.jpg"))); // NOI18N
		jLabel26.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel27.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel27.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel28.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel28.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel29.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/ħ��.jpg"))); // NOI18N
		jLabel29.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel30.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel30.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel31.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel31.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel32.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel32.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel33.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/���.jpg"))); // NOI18N
		jLabel33.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel34.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel34.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel35.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel35.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel36.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel36.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel37.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel37.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel38.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/ҽԺ.jpg"))); // NOI18N
		jLabel38.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel39.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel39.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel40.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�յ�.jpg"))); // NOI18N
		jLabel40.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jTextField1.setFont(new java.awt.Font("���Ŀ���", 1, 30));
		jTextField1.setText("\u5730");
		jTextField1.setBorder(null);

		jTextField2.setFont(new java.awt.Font("���Ŀ���", 1, 30));
		jTextField2.setText("\u56fe");
		jTextField2.setBorder(null);

		jTextField3.setFont(new java.awt.Font("���Ŀ���", 1, 30));
		jTextField3.setText("\u4e00");
		jTextField3.setBorder(null);

		jPanel2.setBackground(new java.awt.Color(255, 255, 252));

		jLabel43.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/����.jpg"))); // NOI18N
		jLabel43.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel44.setFont(new java.awt.Font("���Ŀ���", 1, 14));
		jLabel44
				.setText("\u9053\u5177\u5c4b\uff1a\u53ef\u83b7\u5f97\u8def\u969c\u5361\u3001\u70b8\u5f39\u5361\u3001\u505c\u7559\u5361\u548c\u673a\u5668\u5a03\u5a03\u5361");

		jLabel45.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/��Ʒ.jpg"))); // NOI18N
		jLabel45.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel46.setFont(new java.awt.Font("���Ŀ���", 1, 14));
		jLabel46
				.setText("\u793c\u54c1\u5c4b\uff1a\u53ef\u5f97\u5956\u91d12000\uffe5\u3001\u5361\u70b9\u6570200\u70b9\u3001\u8d22\u795e\u5361\u3001\u623f\u5c4b\u5347\u7ea7\u5361");

		jLabel47.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/ħ��.jpg"))); // NOI18N
		jLabel47.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel48.setFont(new java.awt.Font("���Ŀ���", 1, 14));
		jLabel48
				.setText("\u9b54\u6cd5\u5c4b\uff1a\u53ef\u83b7\u5f97\u8870\u795e\u5361\u3001\u623f\u5c4b\u964d\u7ea7\u5361");

		jLabel49.setFont(new java.awt.Font("���Ŀ���", 1, 14));
		jLabel49
				.setText("\u77ff\u5730\uff1a\u73a9\u5bb6\u7ecf\u8fc7\u53ef\u83b7\u5f97\u5361\u70b9\u6570100");

		jLabel50.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/���.jpg"))); // NOI18N
		jLabel50.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel51.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/ҽԺ.jpg"))); // NOI18N
		jLabel51.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel52.setFont(new java.awt.Font("���Ŀ���", 1, 14));
		jLabel52
				.setText("\u533b\u9662\uff1a\u73a9\u5bb6\u7ecf\u8fc7\u9700\u4f4f\u96622\u5929");

		jLabel53.setFont(new java.awt.Font("���Ŀ���", 1, 14));
		jLabel53
				.setText("\u76d1\u72f1\uff1a\u73a9\u5bb6\u7ecf\u8fc7\u5c06\u88ab\u56da\u79813\u5929");

		jLabel54.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/����.jpg"))); // NOI18N
		jLabel54.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jLabel55.setBackground(new java.awt.Color(253, 254, 240));
		jLabel55.setFont(new java.awt.Font("���Ŀ���", 1, 14));
		jLabel55.setText("\u63d0\u793a\uff1a");

		javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(
				jPanel2);
		jPanel2.setLayout(jPanel2Layout);
		jPanel2Layout
				.setHorizontalGroup(jPanel2Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel2Layout
										.createSequentialGroup()
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addContainerGap()
																		.addGroup(
																				jPanel2Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jLabel55)
																						.addGroup(
																								jPanel2Layout
																										.createSequentialGroup()
																										.addComponent(
																												jLabel50)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
																										.addComponent(
																												jLabel49))))
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGap(
																				80,
																				80,
																				80)
																		.addComponent(
																				jLabel48))
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGap(
																				21,
																				21,
																				21)
																		.addComponent(
																				jLabel45))
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addContainerGap()
																		.addComponent(
																				jLabel54)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jLabel53)))
										.addContainerGap(181, Short.MAX_VALUE))
						.addGroup(
								jPanel2Layout
										.createParallelGroup(
												javax.swing.GroupLayout.Alignment.LEADING)
										.addGroup(
												javax.swing.GroupLayout.Alignment.TRAILING,
												jPanel2Layout
														.createSequentialGroup()
														.addContainerGap(
																javax.swing.GroupLayout.DEFAULT_SIZE,
																Short.MAX_VALUE)
														.addGroup(
																jPanel2Layout
																		.createParallelGroup(
																				javax.swing.GroupLayout.Alignment.LEADING,
																				false)
																		.addComponent(
																				jLabel43)
																		.addComponent(
																				jLabel51)
																		.addComponent(
																				jLabel47,
																				javax.swing.GroupLayout.Alignment.TRAILING))
														.addGroup(
																jPanel2Layout
																		.createParallelGroup(
																				javax.swing.GroupLayout.Alignment.LEADING)
																		.addGroup(
																				jPanel2Layout
																						.createSequentialGroup()
																						.addPreferredGap(
																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																						.addComponent(
																								jLabel52))
																		.addComponent(
																				jLabel46)
																		.addGroup(
																				jPanel2Layout
																						.createSequentialGroup()
																						.addPreferredGap(
																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																						.addComponent(
																								jLabel44)))
														.addContainerGap())));
		jPanel2Layout
				.setVerticalGroup(jPanel2Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel2Layout
										.createSequentialGroup()
										.addContainerGap()
										.addComponent(jLabel55)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												92, Short.MAX_VALUE)
										.addComponent(jLabel45)
										.addGap(29, 29, 29)
										.addComponent(
												jLabel48,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												35,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGap(
																				45,
																				45,
																				45)
																		.addComponent(
																				jLabel50))
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGap(
																				54,
																				54,
																				54)
																		.addComponent(
																				jLabel49,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				35,
																				javax.swing.GroupLayout.PREFERRED_SIZE)))
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING,
																false)
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGap(
																				97,
																				97,
																				97)
																		.addComponent(
																				jLabel54)
																		.addGap(
																				62,
																				62,
																				62))
														.addGroup(
																javax.swing.GroupLayout.Alignment.TRAILING,
																jPanel2Layout
																		.createSequentialGroup()
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				Short.MAX_VALUE)
																		.addComponent(
																				jLabel53,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				34,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addGap(
																				71,
																				71,
																				71))))
						.addGroup(
								jPanel2Layout
										.createParallelGroup(
												javax.swing.GroupLayout.Alignment.LEADING)
										.addGroup(
												jPanel2Layout
														.createSequentialGroup()
														.addGap(43, 43, 43)
														.addGroup(
																jPanel2Layout
																		.createParallelGroup(
																				javax.swing.GroupLayout.Alignment.LEADING)
																		.addGroup(
																				jPanel2Layout
																						.createSequentialGroup()
																						.addComponent(
																								jLabel43)
																						.addGap(
																								107,
																								107,
																								107)
																						.addComponent(
																								jLabel47)
																						.addGap(
																								106,
																								106,
																								106)
																						.addComponent(
																								jLabel51)
																						.addGap(
																								93,
																								93,
																								93))
																		.addGroup(
																				jPanel2Layout
																						.createSequentialGroup()
																						.addGap(
																								9,
																								9,
																								9)
																						.addComponent(
																								jLabel44,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								35,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addGap(
																								48,
																								48,
																								48)
																						.addComponent(
																								jLabel46,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								35,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addPreferredGap(
																								javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																								199,
																								Short.MAX_VALUE)
																						.addComponent(
																								jLabel52,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								35,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addGap(
																								101,
																								101,
																								101)))
														.addGap(44, 44, 44))));

		jButton2.setBackground(new java.awt.Color(255, 255, 255));
		jButton2.setFont(new java.awt.Font("���Ŀ���", 1, 20));
		jButton2.setText("\u8fd4\u56de");
		jButton2.setBorder(null);
		jButton2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton2ActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout
				.setHorizontalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addGroup(
																								javax.swing.GroupLayout.Alignment.TRAILING,
																								jPanel1Layout
																										.createSequentialGroup()
																										.addGroup(
																												jPanel1Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.LEADING)
																														.addGroup(
																																jPanel1Layout
																																		.createSequentialGroup()
																																		.addComponent(
																																				jLabel32)
																																		.addPreferredGap(
																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																																				javax.swing.GroupLayout.DEFAULT_SIZE,
																																				Short.MAX_VALUE)
																																		.addComponent(
																																				jLabel31)
																																		.addPreferredGap(
																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																		.addComponent(
																																				jLabel30))
																														.addGroup(
																																jPanel1Layout
																																		.createSequentialGroup()
																																		.addGroup(
																																				jPanel1Layout
																																						.createParallelGroup(
																																								javax.swing.GroupLayout.Alignment.LEADING)
																																						.addComponent(
																																								jLabel34)
																																						.addComponent(
																																								jLabel38))
																																		.addPreferredGap(
																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																		.addGroup(
																																				jPanel1Layout
																																						.createParallelGroup(
																																								javax.swing.GroupLayout.Alignment.LEADING)
																																						.addComponent(
																																								jLabel36)
																																						.addComponent(
																																								jLabel35)
																																						.addComponent(
																																								jLabel37)))
																														.addComponent(
																																jLabel39))
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addGroup(
																												jPanel1Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.LEADING)
																														.addComponent(
																																jLabel29)
																														.addGroup(
																																jPanel1Layout
																																		.createSequentialGroup()
																																		.addGroup(
																																				jPanel1Layout
																																						.createParallelGroup(
																																								javax.swing.GroupLayout.Alignment.LEADING)
																																						.addGroup(
																																								jPanel1Layout
																																										.createSequentialGroup()
																																										.addComponent(
																																												jLabel28)
																																										.addPreferredGap(
																																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																										.addComponent(
																																												jLabel27))
																																						.addGroup(
																																								jPanel1Layout
																																										.createSequentialGroup()
																																										.addGap(
																																												42,
																																												42,
																																												42)
																																										.addComponent(
																																												jTextField3,
																																												javax.swing.GroupLayout.PREFERRED_SIZE,
																																												javax.swing.GroupLayout.DEFAULT_SIZE,
																																												javax.swing.GroupLayout.PREFERRED_SIZE)))
																																		.addPreferredGap(
																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																		.addGroup(
																																				jPanel1Layout
																																						.createParallelGroup(
																																								javax.swing.GroupLayout.Alignment.LEADING)
																																						.addComponent(
																																								jLabel15)
																																						.addGroup(
																																								jPanel1Layout
																																										.createSequentialGroup()
																																										.addComponent(
																																												jLabel14)
																																										.addPreferredGap(
																																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																										.addComponent(
																																												jLabel13)
																																										.addPreferredGap(
																																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																										.addComponent(
																																												jLabel12))
																																						.addComponent(
																																								jLabel16)
																																						.addGroup(
																																								jPanel1Layout
																																										.createParallelGroup(
																																												javax.swing.GroupLayout.Alignment.TRAILING)
																																										.addGroup(
																																												jPanel1Layout
																																														.createSequentialGroup()
																																														.addComponent(
																																																jLabel26)
																																														.addPreferredGap(
																																																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																														.addComponent(
																																																jLabel25)
																																														.addPreferredGap(
																																																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																														.addComponent(
																																																jLabel24))
																																										.addGroup(
																																												jPanel1Layout
																																														.createSequentialGroup()
																																														.addComponent(
																																																jLabel17)
																																														.addPreferredGap(
																																																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																														.addComponent(
																																																jLabel18)
																																														.addPreferredGap(
																																																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																														.addComponent(
																																																jLabel19)))))))
																						.addComponent(
																								jLabel33)
																						.addGroup(
																								javax.swing.GroupLayout.Alignment.TRAILING,
																								jPanel1Layout
																										.createSequentialGroup()
																										.addGroup(
																												jPanel1Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.TRAILING,
																																false)
																														.addGroup(
																																javax.swing.GroupLayout.Alignment.LEADING,
																																jPanel1Layout
																																		.createSequentialGroup()
																																		.addComponent(
																																				jLabel40)
																																		.addPreferredGap(
																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																																				javax.swing.GroupLayout.DEFAULT_SIZE,
																																				Short.MAX_VALUE)
																																		.addComponent(
																																				jTextField1,
																																				javax.swing.GroupLayout.PREFERRED_SIZE,
																																				javax.swing.GroupLayout.DEFAULT_SIZE,
																																				javax.swing.GroupLayout.PREFERRED_SIZE))
																														.addGroup(
																																jPanel1Layout
																																		.createSequentialGroup()
																																		.addComponent(
																																				jLabel1)
																																		.addPreferredGap(
																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																		.addComponent(
																																				jLabel2)
																																		.addPreferredGap(
																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																		.addComponent(
																																				jLabel3)))
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addGroup(
																												jPanel1Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.LEADING)
																														.addComponent(
																																jTextField2,
																																javax.swing.GroupLayout.PREFERRED_SIZE,
																																javax.swing.GroupLayout.DEFAULT_SIZE,
																																javax.swing.GroupLayout.PREFERRED_SIZE)
																														.addGroup(
																																jPanel1Layout
																																		.createSequentialGroup()
																																		.addComponent(
																																				jLabel4)
																																		.addPreferredGap(
																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																		.addComponent(
																																				jLabel5)
																																		.addPreferredGap(
																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																		.addComponent(
																																				jLabel6)
																																		.addPreferredGap(
																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																		.addComponent(
																																				jLabel7)
																																		.addPreferredGap(
																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																		.addComponent(
																																				jLabel8)))))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jLabel9)
																						.addComponent(
																								jLabel10)
																						.addComponent(
																								jLabel11)
																						.addComponent(
																								jLabel20)
																						.addComponent(
																								jLabel21)
																						.addComponent(
																								jLabel23)
																						.addComponent(
																								jLabel22))
																		.addGap(
																				25,
																				25,
																				25)
																		.addComponent(
																				jPanel2,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addContainerGap())
														.addGroup(
																javax.swing.GroupLayout.Alignment.TRAILING,
																jPanel1Layout
																		.createSequentialGroup()
																		.addComponent(
																				jButton2)
																		.addGap(
																				30,
																				30,
																				30)))));
		jPanel1Layout
				.setVerticalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addGap(
																				23,
																				23,
																				23)
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addGroup(
																								jPanel1Layout
																										.createSequentialGroup()
																										.addGap(
																												26,
																												26,
																												26)
																										.addGroup(
																												jPanel1Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.LEADING)
																														.addComponent(
																																jLabel9)
																														.addComponent(
																																jLabel8)
																														.addComponent(
																																jLabel7)
																														.addComponent(
																																jLabel6)
																														.addComponent(
																																jLabel5)
																														.addComponent(
																																jLabel4)
																														.addComponent(
																																jLabel3)
																														.addComponent(
																																jLabel2)
																														.addComponent(
																																jLabel1))
																										.addGroup(
																												jPanel1Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.TRAILING)
																														.addGroup(
																																javax.swing.GroupLayout.Alignment.LEADING,
																																jPanel1Layout
																																		.createSequentialGroup()
																																		.addPreferredGap(
																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																		.addGroup(
																																				jPanel1Layout
																																						.createParallelGroup(
																																								javax.swing.GroupLayout.Alignment.TRAILING)
																																						.addGroup(
																																								jPanel1Layout
																																										.createSequentialGroup()
																																										.addGroup(
																																												jPanel1Layout
																																														.createParallelGroup(
																																																javax.swing.GroupLayout.Alignment.LEADING)
																																														.addGroup(
																																																jPanel1Layout
																																																		.createSequentialGroup()
																																																		.addComponent(
																																																				jLabel40)
																																																		.addPreferredGap(
																																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																																																				javax.swing.GroupLayout.DEFAULT_SIZE,
																																																				Short.MAX_VALUE)
																																																		.addComponent(
																																																				jLabel39)
																																																		.addPreferredGap(
																																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																																		.addGroup(
																																																				jPanel1Layout
																																																						.createParallelGroup(
																																																								javax.swing.GroupLayout.Alignment.TRAILING)
																																																						.addComponent(
																																																								jLabel38)
																																																						.addComponent(
																																																								jLabel37))
																																																		.addPreferredGap(
																																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																																		.addComponent(
																																																				jLabel36)
																																																		.addPreferredGap(
																																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																																		.addGroup(
																																																				jPanel1Layout
																																																						.createParallelGroup(
																																																								javax.swing.GroupLayout.Alignment.LEADING)
																																																						.addGroup(
																																																								jPanel1Layout
																																																										.createSequentialGroup()
																																																										.addComponent(
																																																												jLabel34)
																																																										.addPreferredGap(
																																																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																																										.addComponent(
																																																												jLabel33))
																																																						.addComponent(
																																																								jLabel35)))
																																														.addGroup(
																																																jPanel1Layout
																																																		.createSequentialGroup()
																																																		.addGap(
																																																				48,
																																																				48,
																																																				48)
																																																		.addComponent(
																																																				jTextField1,
																																																				javax.swing.GroupLayout.PREFERRED_SIZE,
																																																				javax.swing.GroupLayout.DEFAULT_SIZE,
																																																				javax.swing.GroupLayout.PREFERRED_SIZE)
																																																		.addGap(
																																																				7,
																																																				7,
																																																				7)
																																																		.addComponent(
																																																				jTextField2,
																																																				javax.swing.GroupLayout.PREFERRED_SIZE,
																																																				javax.swing.GroupLayout.DEFAULT_SIZE,
																																																				javax.swing.GroupLayout.PREFERRED_SIZE)))
																																										.addPreferredGap(
																																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																										.addGroup(
																																												jPanel1Layout
																																														.createParallelGroup(
																																																javax.swing.GroupLayout.Alignment.LEADING)
																																														.addComponent(
																																																jLabel30)
																																														.addGroup(
																																																jPanel1Layout
																																																		.createSequentialGroup()
																																																		.addComponent(
																																																				jLabel29)
																																																		.addPreferredGap(
																																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																																		.addComponent(
																																																				jLabel28))
																																														.addComponent(
																																																jLabel31)
																																														.addComponent(
																																																jLabel32)))
																																						.addGroup(
																																								jPanel1Layout
																																										.createSequentialGroup()
																																										.addComponent(
																																												jLabel10)
																																										.addPreferredGap(
																																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																										.addGroup(
																																												jPanel1Layout
																																														.createParallelGroup(
																																																javax.swing.GroupLayout.Alignment.LEADING)
																																														.addComponent(
																																																jLabel11)
																																														.addComponent(
																																																jLabel12)
																																														.addComponent(
																																																jLabel13)
																																														.addComponent(
																																																jLabel14))
																																										.addPreferredGap(
																																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																										.addComponent(
																																												jLabel15)
																																										.addPreferredGap(
																																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																										.addComponent(
																																												jLabel16)
																																										.addPreferredGap(
																																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																										.addGroup(
																																												jPanel1Layout
																																														.createParallelGroup(
																																																javax.swing.GroupLayout.Alignment.LEADING)
																																														.addComponent(
																																																jLabel17)
																																														.addComponent(
																																																jLabel18)
																																														.addComponent(
																																																jLabel19)
																																														.addComponent(
																																																jLabel20))
																																										.addPreferredGap(
																																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																										.addGroup(
																																												jPanel1Layout
																																														.createParallelGroup(
																																																javax.swing.GroupLayout.Alignment.TRAILING)
																																														.addComponent(
																																																jLabel24)
																																														.addComponent(
																																																jLabel25)
																																														.addComponent(
																																																jLabel26)
																																														.addGroup(
																																																jPanel1Layout
																																																		.createSequentialGroup()
																																																		.addComponent(
																																																				jLabel21)
																																																		.addPreferredGap(
																																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																																		.addComponent(
																																																				jLabel22)
																																																		.addPreferredGap(
																																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																																		.addComponent(
																																																				jLabel23))))))
																														.addGroup(
																																jPanel1Layout
																																		.createSequentialGroup()
																																		.addGap(
																																				158,
																																				158,
																																				158)
																																		.addComponent(
																																				jTextField3,
																																				javax.swing.GroupLayout.PREFERRED_SIZE,
																																				javax.swing.GroupLayout.DEFAULT_SIZE,
																																				javax.swing.GroupLayout.PREFERRED_SIZE)
																																		.addPreferredGap(
																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																																				230,
																																				Short.MAX_VALUE)
																																		.addComponent(
																																				jLabel27))))
																						.addGroup(
																								jPanel1Layout
																										.createSequentialGroup()
																										.addGap(
																												56,
																												56,
																												56)
																										.addComponent(
																												jPanel2,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												486,
																												javax.swing.GroupLayout.PREFERRED_SIZE))))
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addContainerGap()
																		.addComponent(
																				jButton2)))
										.addContainerGap()));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.PREFERRED_SIZE));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
		new Record().setVisible(true);
		this.dispose();
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		try {
			org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.launchBeautyEyeLNF();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new Map1().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton2;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel10;
	private javax.swing.JLabel jLabel11;
	private javax.swing.JLabel jLabel12;
	private javax.swing.JLabel jLabel13;
	private javax.swing.JLabel jLabel14;
	private javax.swing.JLabel jLabel15;
	private javax.swing.JLabel jLabel16;
	private javax.swing.JLabel jLabel17;
	private javax.swing.JLabel jLabel18;
	private javax.swing.JLabel jLabel19;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel20;
	private javax.swing.JLabel jLabel21;
	private javax.swing.JLabel jLabel22;
	private javax.swing.JLabel jLabel23;
	private javax.swing.JLabel jLabel24;
	private javax.swing.JLabel jLabel25;
	private javax.swing.JLabel jLabel26;
	private javax.swing.JLabel jLabel27;
	private javax.swing.JLabel jLabel28;
	private javax.swing.JLabel jLabel29;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel30;
	private javax.swing.JLabel jLabel31;
	private javax.swing.JLabel jLabel32;
	private javax.swing.JLabel jLabel33;
	private javax.swing.JLabel jLabel34;
	private javax.swing.JLabel jLabel35;
	private javax.swing.JLabel jLabel36;
	private javax.swing.JLabel jLabel37;
	private javax.swing.JLabel jLabel38;
	private javax.swing.JLabel jLabel39;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel40;
	private javax.swing.JLabel jLabel43;
	private javax.swing.JLabel jLabel44;
	private javax.swing.JLabel jLabel45;
	private javax.swing.JLabel jLabel46;
	private javax.swing.JLabel jLabel47;
	private javax.swing.JLabel jLabel48;
	private javax.swing.JLabel jLabel49;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JLabel jLabel50;
	private javax.swing.JLabel jLabel51;
	private javax.swing.JLabel jLabel52;
	private javax.swing.JLabel jLabel53;
	private javax.swing.JLabel jLabel54;
	private javax.swing.JLabel jLabel55;
	private javax.swing.JLabel jLabel6;
	private javax.swing.JLabel jLabel7;
	private javax.swing.JLabel jLabel8;
	private javax.swing.JLabel jLabel9;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JTextField jTextField1;
	private javax.swing.JTextField jTextField2;
	private javax.swing.JTextField jTextField3;
	// End of variables declaration//GEN-END:variables

}