package game;

import java.io.UnsupportedEncodingException;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.GroupLayout.Alignment;
import javax.swing.SwingConstants;
import javax.swing.JOptionPane;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.Icon;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import gui.GameCard;
import gui.GameRole;
import gui.GameRule;
import gui.MyMessage;
import login.ChooseLoginWay;
import login.ChooseWay;
import style.SetSwing;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class GameStart3 extends javax.swing.JFrame implements ActionListener {
	private static final long serialVersionUID = 1L;
	/* ��ͼ40������ */
	JLabel[] label = new JLabel[40];
	JLabel jLabel1 = new SetSwing().getMapLabel("���");
	JLabel jLabel2 = new SetSwing().getMapLabel("�յ�");
	JLabel jLabel3 = new SetSwing().getMapLabel("�յ�");
	JLabel jLabel4 = new SetSwing().getMapLabel("�յ�");
	JLabel jLabel5 = new SetSwing().getMapLabel("ҽԺ");
	JLabel jLabel6 = new SetSwing().getMapLabel("�յ�");
	JLabel jLabel7 = new SetSwing().getMapLabel("���");
	JLabel jLabel8 = new SetSwing().getMapLabel("�յ�");
	JLabel jLabel9 = new SetSwing().getMapLabel("�յ�");
	JLabel jLabel10 = new SetSwing().getMapLabel("����");
	JLabel jLabel11 = new SetSwing().getMapLabel("�յ�");
	JLabel jLabel12 = new SetSwing().getMapLabel("�յ�");
	JLabel jLabel13 = new SetSwing().getMapLabel("��Ʒ");
	JLabel jLabel14 = new SetSwing().getMapLabel("�յ�");
	JLabel jLabel15 = new SetSwing().getMapLabel("�յ�");
	JLabel jLabel16 = new SetSwing().getMapLabel("����");
	JLabel jLabel17 = new SetSwing().getMapLabel("�յ�");
	JLabel jLabel18 = new SetSwing().getMapLabel("�յ�");
	JLabel jLabel19 = new SetSwing().getMapLabel("���");
	JLabel jLabel20 = new SetSwing().getMapLabel("�յ�");
	JLabel jLabel21 = new SetSwing().getMapLabel("��Ʒ");
	JLabel jLabel22 = new SetSwing().getMapLabel("�յ�");
	JLabel jLabel23 = new SetSwing().getMapLabel("����");
	JLabel jLabel24 = new SetSwing().getMapLabel("�յ�");
	JLabel jLabel25 = new SetSwing().getMapLabel("�յ�");
	JLabel jLabel26 = new SetSwing().getMapLabel("����");
	JLabel jLabel27 = new SetSwing().getMapLabel("�յ�");
	JLabel jLabel28 = new SetSwing().getMapLabel("�յ�");
	JLabel jLabel29 = new SetSwing().getMapLabel("ħ��");
	JLabel jLabel30 = new SetSwing().getMapLabel("�յ�");
	JLabel jLabel31 = new SetSwing().getMapLabel("�յ�");
	JLabel jLabel32 = new SetSwing().getMapLabel("�յ�");
	JLabel jLabel33 = new SetSwing().getMapLabel("���");
	JLabel jLabel34 = new SetSwing().getMapLabel("�յ�");
	JLabel jLabel35 = new SetSwing().getMapLabel("�յ�");
	JLabel jLabel36 = new SetSwing().getMapLabel("�յ�");
	JLabel jLabel37 = new SetSwing().getMapLabel("�յ�");
	JLabel jLabel38 = new SetSwing().getMapLabel("ҽԺ");
	JLabel jLabel39 = new SetSwing().getMapLabel("�յ�");
	JLabel jLabel40 = new SetSwing().getMapLabel("�յ�");
	/* �˵�Ԫ��7�� */
	private JButton menuButton1 = new SetSwing().getMenuButton("\u6211\u7684\u8d44\u6599");
	private JButton menuButton2 = new SetSwing().getMenuButton("\u6e38\u620f\u89c4\u5219");
	private JButton menuButton3 = new SetSwing().getMenuButton("\u89d2\u8272\u4ecb\u7ecd");
	private JButton menuButton4 = new SetSwing().getMenuButton("\u9053\u5177\u4f7f\u7528");
	private JButton menuButton5 = new SetSwing().getMenuButton("\u767b\u5f55");
	private JButton menuButton6 = new SetSwing().getMenuButton("\u8fd4\u56de");
	private JButton menuButton7 = new SetSwing().getMenuButton("\u9000\u51FA");
	/* ��ƬԪ��9�� */
	private JButton cardButton1;
	private JButton cardButton2;
	private JButton cardButton3;
	private JButton cardButton4;
	private JButton cardButton5;
	private JButton cardButton6;
	private JButton cardButton7;
	private JButton cardButton8;
	private JButton cardButton9;
	/* ��ɫ��Ϣ */
	private JLabel jLabel41;
	private JLabel jLabel42 = new JLabel("��һ����ɫ��");
	private JLabel jLabel43 = new JLabel();
	private JLabel jLabel44 = new JLabel("�ڶ�����ɫ��");
	private JLabel jLabel45 = new JLabel();
	private JLabel moneyLabel = new SetSwing().getAttributeLabel("\u6211\u7684\u8d44\u91d1\uff1a");
	private JLabel cardNumberLabel = new SetSwing().getAttributeLabel("\u5361\u70b9\u6570\uff1a");
	private JLabel roomNumberLabel = new SetSwing().getAttributeLabel("\u623f\u5b50\uff1a");
	private JButton startButton;
	private javax.swing.JLabel jLabel49;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JTextField moneyField;
	private javax.swing.JTextField cardNumberField;
	private javax.swing.JTextField roomNumberField;
	private javax.swing.JTextField text3;
	private javax.swing.JTextField text1;
	private javax.swing.JTextField text2;
	private JButton jButton10;
	private JTextField textField;
	String[] buttonName = { "ͣ����", "·�Ͽ�", "���ݽ�����", "�������޿�", "����", "����������", "ը����", "���ʿ�", "˥��" };
	JButton[] cardButton = new JButton[9];
	/* ����Ʋ� */
	private String[] personList = { "", "" };
	private int people = 0; // ��ǰ��ɫ
	private int[] money = { 1000, 1000 };// ��ɫ��Ǯ��
	private int[] cardNumber = { 0, 0 };// ��ɫ������
	private int[] roomNumber = { 0, 0 };// ��ɫ������
	private int[][] card = { { 1, 1, 1, 1, 1, 1, 1, 1, 1 }, { 1, 1, 1, 1, 1, 1, 1, 1, 1 } };// ��ɫ���߿�����
	private int[] location = { 0, 0 };// ��ɫ����λ��

	public GameStart3(String[] personList) {
		this.personList = personList;
		this.setBounds(200, -40, 1100, 900);
		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jPanel1 = new javax.swing.JPanel();
		jPanel2 = new javax.swing.JPanel();
		jPanel1.setBackground(new java.awt.Color(232, 232, 251));
		jPanel2.setBackground(new java.awt.Color(232, 232, 251));

		jButton10 = new JButton();
		/* �ؿ�˵�� */
		text1 = new javax.swing.JTextField("\u5173");
		text1.setBackground(new java.awt.Color(232, 232, 251));
		text1.setFont(new java.awt.Font("���Ŀ���", 1, 30));
		text1.setBorder(null);
		text2 = new javax.swing.JTextField("\u5361");
		text2.setBackground(new java.awt.Color(232, 232, 251));
		text2.setFont(new java.awt.Font("���Ŀ���", 1, 30));
		text2.setBorder(null);
		text3 = new javax.swing.JTextField("\u4e00");
		text3.setBackground(new java.awt.Color(232, 232, 251));
		text3.setFont(new java.awt.Font("���Ŀ���", 1, 30));
		text3.setBorder(null);
		/* �ؿ�˵��end */
		/* ��ʼ��ť */
		startButton = new JButton();
		startButton.setIcon(new ImageIcon(GameStart3.class.getResource("/image/map/\u8D77\u70B9.jpg")));
		startButton.setBackground(new java.awt.Color(255, 255, 255));
		startButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				go(evt);
			}
		});
		/* �˵��� */
		menuButton1.addActionListener(new meunEvent());
		menuButton2.addActionListener(new meunEvent());
		menuButton3.addActionListener(new meunEvent());
		menuButton4.addActionListener(new meunEvent());
		menuButton5.addActionListener(new meunEvent());
		menuButton6.addActionListener(new meunEvent());
		menuButton7.addActionListener(new meunEvent());
		/* �˵���end */
		/* ����ѡ�� */
		jLabel41 = new JLabel("\u8bf7\u9009\u62e9\u89d2\u8272\uff1a");
		jLabel41.setBackground(new java.awt.Color(232, 232, 251));
		jLabel41.setFont(new java.awt.Font("���Ŀ���", 1, 14));
		jLabel43 = new SetSwing().getPersonButton(personList[0]);
		jLabel45 = new SetSwing().getPersonButton(personList[1]);
		/* ����ѡ��end */
		/* �������� */
		moneyField = new JTextField();
		moneyField.setHorizontalAlignment(SwingConstants.CENTER);
		moneyField.setEnabled(false);
		cardNumberField = new JTextField();
		cardNumberField.setHorizontalAlignment(SwingConstants.CENTER);
		cardNumberField.setEnabled(false);
		roomNumberField = new JTextField();
		roomNumberField.setHorizontalAlignment(SwingConstants.CENTER);
		roomNumberField.setEnabled(false);
		textField = new JTextField();
		textField.setEnabled(false);
		textField.setColumns(10);
		/* ��������end */
		/* ��Ƭѡ�� */
		cardButton1 = new SetSwing().getCardButton();
		cardButton2 = new SetSwing().getCardButton();
		cardButton3 = new SetSwing().getCardButton();
		cardButton4 = new SetSwing().getCardButton();
		cardButton5 = new SetSwing().getCardButton();
		cardButton6 = new SetSwing().getCardButton();
		cardButton7 = new SetSwing().getCardButton();
		cardButton8 = new SetSwing().getCardButton();
		cardButton9 = new SetSwing().getCardButton();
		cardButton[0] = cardButton1;
		cardButton[1] = cardButton2;
		cardButton[2] = cardButton3;
		cardButton[3] = cardButton4;
		cardButton[4] = cardButton5;
		cardButton[5] = cardButton6;
		cardButton[6] = cardButton7;
		cardButton[7] = cardButton8;
		cardButton[8] = cardButton9;
		for (int i = 0, len = cardButton.length; i < len; i++) {
			cardButton[i].addActionListener(this);
			cardButton[i].setIcon(
					new javax.swing.ImageIcon(getClass().getResource(String.format("/img/%s��С��.jpg", buttonName[i]))));
		}
		/* ��Ƭѡ��end */
		/* ��ͼ */
		label[0] = jLabel1;
		label[1] = jLabel2;
		label[2] = jLabel3;
		label[3] = jLabel4;
		label[4] = jLabel5;
		label[5] = jLabel6;
		label[6] = jLabel7;
		label[7] = jLabel8;
		label[8] = jLabel9;
		label[9] = jLabel10;
		label[10] = jLabel11;
		label[11] = jLabel12;
		label[12] = jLabel13;
		label[13] = jLabel14;
		label[14] = jLabel15;
		label[15] = jLabel16;
		label[16] = jLabel17;
		label[17] = jLabel18;
		label[18] = jLabel19;
		label[19] = jLabel20;
		label[20] = jLabel21;
		label[21] = jLabel22;
		label[22] = jLabel23;
		label[23] = jLabel24;
		label[24] = jLabel25;
		label[25] = jLabel26;
		label[26] = jLabel27;
		label[27] = jLabel28;
		label[28] = jLabel29;
		label[29] = jLabel30;
		label[30] = jLabel31;
		label[31] = jLabel32;
		label[32] = jLabel33;
		label[33] = jLabel34;
		label[34] = jLabel35;
		label[35] = jLabel36;
		label[36] = jLabel37;
		label[37] = jLabel38;
		label[38] = jLabel39;
		label[39] = jLabel40;
		/* ��ͼend */
		jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/ͣ������С��.jpg")));
		jLabel49 = new javax.swing.JLabel(
				"\u4ee5\u4e0b\u663e\u793a\u7eff\u8272\u7684\u4e3a\u53ef\u7528\u5361\u724c\uff1a");
		jLabel49.setFont(new java.awt.Font("���Ŀ���", 1, 14));
		javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
		jPanel2.setLayout(jPanel2Layout);
		jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel2Layout.createSequentialGroup().addGroup(jPanel2Layout
						.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(jPanel2Layout.createSequentialGroup().addGap(269, 269, 269).addComponent(text3,
								javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE,
								javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGroup(jPanel2Layout.createSequentialGroup().addGap(235, 235, 235).addComponent(text2,
								javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE,
								javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGroup(jPanel2Layout.createSequentialGroup().addGap(204, 204, 204).addComponent(text1,
								javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE,
								javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addContainerGap(321, Short.MAX_VALUE))
				.addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(jPanel2Layout.createSequentialGroup().addGap(49, 49, 49).addGroup(jPanel2Layout
								.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout
										.createSequentialGroup()
										.addGroup(jPanel2Layout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addGroup(jPanel2Layout.createSequentialGroup().addComponent(jLabel32)
														.addPreferredGap(
																javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
														.addComponent(jLabel31).addPreferredGap(
																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
														.addComponent(jLabel30))
												.addGroup(jPanel2Layout.createSequentialGroup().addGroup(jPanel2Layout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(jLabel34).addComponent(jLabel38)).addPreferredGap(
																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
														.addGroup(jPanel2Layout.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING).addComponent(
																		jLabel36)
																.addComponent(jLabel35).addComponent(jLabel37)))
												.addComponent(jLabel39))
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(jPanel2Layout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(jLabel29)
												.addGroup(jPanel2Layout.createSequentialGroup().addComponent(jLabel28)
														.addPreferredGap(
																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
														.addComponent(jLabel27)
														.addPreferredGap(
																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
														.addGroup(jPanel2Layout
																.createParallelGroup(
																		javax.swing.GroupLayout.Alignment.LEADING)
																.addComponent(jLabel15)
																.addGroup(jPanel2Layout.createSequentialGroup()
																		.addComponent(jLabel14)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(jLabel13)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(jLabel12))
																.addComponent(jLabel16)
																.addGroup(jPanel2Layout.createParallelGroup(
																		javax.swing.GroupLayout.Alignment.TRAILING)
																		.addGroup(jPanel2Layout.createSequentialGroup()
																				.addComponent(jLabel26)
																				.addPreferredGap(
																						javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																				.addComponent(jLabel25)
																				.addPreferredGap(
																						javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																				.addComponent(jLabel24))
																		.addGroup(jPanel2Layout.createSequentialGroup()
																				.addComponent(jLabel17)
																				.addPreferredGap(
																						javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																				.addComponent(jLabel18)
																				.addPreferredGap(
																						javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																				.addComponent(jLabel19)))))))
								.addComponent(jLabel33).addGroup(javax.swing.GroupLayout.Alignment.TRAILING,
										jPanel2Layout.createSequentialGroup().addGroup(jPanel2Layout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
												.addGroup(javax.swing.GroupLayout.Alignment.LEADING,
														jPanel2Layout.createSequentialGroup().addComponent(jLabel40)
																.addGap(118, 118, 118))
												.addGroup(jPanel2Layout.createSequentialGroup().addComponent(jLabel1)
														.addPreferredGap(
																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
														.addComponent(jLabel2)
														.addPreferredGap(
																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
														.addComponent(jLabel3)))
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(jLabel4)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(jLabel5)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(jLabel6)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(jLabel7)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(jLabel8)))
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addComponent(jLabel9).addComponent(jLabel10).addComponent(jLabel11)
										.addComponent(jLabel20).addComponent(jLabel21).addComponent(jLabel23)
										.addComponent(jLabel22))
								.addGap(49, 49, 49))));
		jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel2Layout.createSequentialGroup().addGap(177, 177, 177)
						.addComponent(text1, javax.swing.GroupLayout.PREFERRED_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGap(27, 27, 27)
						.addComponent(text2, javax.swing.GroupLayout.PREFERRED_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGap(23, 23, 23)
						.addComponent(text3, javax.swing.GroupLayout.PREFERRED_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(214, Short.MAX_VALUE))
				.addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(jPanel2Layout.createSequentialGroup().addGap(14, 14, 14)
								.addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addComponent(jLabel9).addComponent(jLabel8).addComponent(jLabel7)
										.addComponent(jLabel6).addComponent(jLabel5).addComponent(jLabel4)
										.addComponent(jLabel3).addComponent(jLabel2).addComponent(jLabel1))
								.addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
										.addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout
												.createSequentialGroup()
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addGroup(jPanel2Layout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
														.addGroup(jPanel2Layout.createSequentialGroup()
																.addComponent(jLabel40)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																		javax.swing.GroupLayout.DEFAULT_SIZE,
																		Short.MAX_VALUE)
																.addComponent(jLabel39)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addGroup(jPanel2Layout.createParallelGroup(
																		javax.swing.GroupLayout.Alignment.TRAILING)
																		.addComponent(jLabel38).addComponent(jLabel37))
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addComponent(jLabel36)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addGroup(jPanel2Layout.createParallelGroup(
																		javax.swing.GroupLayout.Alignment.LEADING)
																		.addGroup(jPanel2Layout.createSequentialGroup()
																				.addComponent(jLabel34)
																				.addPreferredGap(
																						javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																				.addComponent(jLabel33))
																		.addComponent(jLabel35))
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addGroup(jPanel2Layout.createParallelGroup(
																		javax.swing.GroupLayout.Alignment.LEADING)
																		.addComponent(jLabel30)
																		.addGroup(jPanel2Layout.createSequentialGroup()
																				.addComponent(jLabel29)
																				.addPreferredGap(
																						javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																				.addComponent(jLabel28))
																		.addComponent(jLabel31).addComponent(jLabel32)))
														.addGroup(jPanel2Layout.createSequentialGroup()
																.addComponent(jLabel10)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addGroup(jPanel2Layout.createParallelGroup(
																		javax.swing.GroupLayout.Alignment.LEADING)
																		.addComponent(jLabel11).addComponent(jLabel12)
																		.addComponent(jLabel13).addComponent(jLabel14))
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addComponent(jLabel15)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addComponent(jLabel16)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addGroup(jPanel2Layout.createParallelGroup(
																		javax.swing.GroupLayout.Alignment.LEADING)
																		.addComponent(jLabel17).addComponent(jLabel18)
																		.addComponent(jLabel19).addComponent(jLabel20))
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addGroup(jPanel2Layout.createParallelGroup(
																		javax.swing.GroupLayout.Alignment.TRAILING)
																		.addComponent(jLabel24).addComponent(jLabel25)
																		.addComponent(jLabel26)
																		.addGroup(jPanel2Layout.createSequentialGroup()
																				.addComponent(jLabel21)
																				.addPreferredGap(
																						javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																				.addComponent(jLabel22)
																				.addPreferredGap(
																						javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																				.addComponent(jLabel23))))))
										.addGroup(jPanel2Layout.createSequentialGroup().addGap(428, 428, 428)
												.addComponent(jLabel27)))
								.addGap(15, 15, 15))));
		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING).addGroup(jPanel1Layout
				.createSequentialGroup().addContainerGap()
				.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING).addGroup(jPanel1Layout
						.createSequentialGroup()
						.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING).addGroup(jPanel1Layout
								.createSequentialGroup().addGap(23)
								.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING).addComponent(jLabel41)
										.addGroup(jPanel1Layout.createSequentialGroup().addGap(5).addGroup(jPanel1Layout
												.createParallelGroup(Alignment.TRAILING).addComponent(jLabel42)
												.addGroup(jPanel1Layout.createSequentialGroup()
														.addComponent(jButton10, GroupLayout.PREFERRED_SIZE, 0,
																GroupLayout.PREFERRED_SIZE)
														.addPreferredGap(ComponentPlacement.RELATED)
														.addComponent(jLabel44)))
												.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
														.addGroup(jPanel1Layout.createSequentialGroup().addGap(18)
																.addGroup(jPanel1Layout
																		.createParallelGroup(Alignment.LEADING)
																		.addComponent(jLabel45).addComponent(jLabel43)))
														.addGroup(jPanel1Layout.createSequentialGroup()
																.addPreferredGap(ComponentPlacement.RELATED)
																.addComponent(textField, GroupLayout.PREFERRED_SIZE,
																		GroupLayout.DEFAULT_SIZE,
																		GroupLayout.PREFERRED_SIZE))))))
								.addGroup(
										jPanel1Layout.createSequentialGroup()
												.addComponent(cardButton1, GroupLayout.PREFERRED_SIZE, 60,
														GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(ComponentPlacement.RELATED)
												.addComponent(cardButton2, GroupLayout.PREFERRED_SIZE, 60,
														GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(ComponentPlacement.RELATED).addComponent(cardButton3,
														GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE))
								.addGroup(
										jPanel1Layout.createSequentialGroup()
												.addComponent(cardButton4, GroupLayout.PREFERRED_SIZE, 60,
														GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(ComponentPlacement.RELATED)
												.addComponent(cardButton5, GroupLayout.PREFERRED_SIZE, 60,
														GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(ComponentPlacement.RELATED).addComponent(cardButton6,
														GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE))
								.addGroup(
										jPanel1Layout.createSequentialGroup()
												.addComponent(cardButton7, GroupLayout.PREFERRED_SIZE, 60,
														GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(ComponentPlacement.RELATED)
												.addComponent(cardButton8, GroupLayout.PREFERRED_SIZE, 60,
														GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(ComponentPlacement.RELATED).addComponent(cardButton9,
														GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE))
								.addComponent(jLabel49))
						.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
								.addGroup(jPanel1Layout.createSequentialGroup().addGap(18)
										.addComponent(jPanel2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
												GroupLayout.PREFERRED_SIZE)
										.addGap(22).addComponent(startButton, GroupLayout.PREFERRED_SIZE, 97,
												GroupLayout.PREFERRED_SIZE))
								.addGroup(jPanel1Layout.createSequentialGroup().addGap(64).addComponent(moneyLabel)
										.addPreferredGap(ComponentPlacement.RELATED)
										.addComponent(moneyField, GroupLayout.PREFERRED_SIZE, 54,
												GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(ComponentPlacement.UNRELATED).addComponent(cardNumberLabel)
										.addPreferredGap(ComponentPlacement.RELATED)
										.addComponent(cardNumberField, GroupLayout.PREFERRED_SIZE, 58,
												GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(ComponentPlacement.UNRELATED).addComponent(roomNumberLabel)
										.addPreferredGap(ComponentPlacement.RELATED).addComponent(roomNumberField,
												GroupLayout.PREFERRED_SIZE, 61, GroupLayout.PREFERRED_SIZE)))
						.addContainerGap(61, Short.MAX_VALUE))
						.addGroup(jPanel1Layout.createSequentialGroup().addComponent(menuButton1)
								.addPreferredGap(ComponentPlacement.RELATED).addComponent(menuButton2)
								.addPreferredGap(ComponentPlacement.RELATED).addComponent(menuButton3)
								.addPreferredGap(ComponentPlacement.RELATED).addComponent(menuButton4)
								.addPreferredGap(ComponentPlacement.RELATED, 353, Short.MAX_VALUE)
								.addComponent(menuButton5).addPreferredGap(ComponentPlacement.RELATED)
								.addComponent(menuButton6).addGap(5).addComponent(menuButton7).addGap(28)))));
		jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING).addGroup(jPanel1Layout
				.createSequentialGroup().addContainerGap()
				.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING, false)
						.addComponent(menuButton2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(menuButton3, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(menuButton4, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(menuButton6, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(menuButton5, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(menuButton1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(menuButton7))
				.addPreferredGap(ComponentPlacement.RELATED).addGroup(
						jPanel1Layout
								.createParallelGroup(
										Alignment.LEADING)
								.addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout
										.createParallelGroup(Alignment.LEADING)
										.addGroup(jPanel1Layout.createSequentialGroup().addGap(84).addComponent(
												jLabel41).addGap(29)
												.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
														.addComponent(jLabel42).addComponent(jLabel43))
												.addGap(12)
												.addGroup(jPanel1Layout
														.createParallelGroup(Alignment.LEADING).addGroup(jPanel1Layout
																.createSequentialGroup().addGap(40)
																.addComponent(jButton10, GroupLayout.DEFAULT_SIZE, 131,
																		Short.MAX_VALUE))
														.addGroup(jPanel1Layout.createSequentialGroup().addGap(2)
																.addGroup(jPanel1Layout
																		.createParallelGroup(Alignment.LEADING)
																		.addComponent(jLabel44).addComponent(jLabel45))
																.addGap(38)
																.addComponent(textField, GroupLayout.PREFERRED_SIZE,
																		GroupLayout.DEFAULT_SIZE,
																		GroupLayout.PREFERRED_SIZE)
																.addGap(38)))
												.addPreferredGap(ComponentPlacement.RELATED).addComponent(jLabel49)
												.addPreferredGap(ComponentPlacement.RELATED).addGroup(jPanel1Layout
														.createParallelGroup(Alignment.LEADING)
														.addComponent(cardButton1).addComponent(cardButton2)
														.addComponent(cardButton3))
												.addPreferredGap(ComponentPlacement.RELATED)
												.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
														.addComponent(cardButton6).addComponent(cardButton5)
														.addGroup(jPanel1Layout.createSequentialGroup()
																.addComponent(cardButton4)
																.addPreferredGap(ComponentPlacement.RELATED)
																.addGroup(jPanel1Layout
																		.createParallelGroup(Alignment.LEADING)
																		.addComponent(cardButton8)
																		.addComponent(cardButton7)
																		.addComponent(cardButton9))))
												.addGap(75))
										.addGroup(jPanel1Layout.createSequentialGroup().addGap(60)
												.addComponent(jPanel2, GroupLayout.PREFERRED_SIZE,
														GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
												.addGap(39)
												.addGroup(jPanel1Layout.createParallelGroup(Alignment.BASELINE)
														.addComponent(moneyLabel)
														.addComponent(moneyField, GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
														.addComponent(cardNumberLabel)
														.addComponent(cardNumberField, GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
														.addComponent(roomNumberLabel).addComponent(roomNumberField,
																GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE))
												.addGap(52)))
										.addGap(493))
								.addGroup(jPanel1Layout
										.createSequentialGroup().addGap(516).addComponent(startButton,
												GroupLayout.PREFERRED_SIZE, 94, GroupLayout.PREFERRED_SIZE)
										.addContainerGap()))));
		jPanel1.setLayout(jPanel1Layout);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGap(0, 1025, Short.MAX_VALUE).addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE,
						javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout.setVerticalGroup(
				layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGap(0, 766, Short.MAX_VALUE)
						.addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 766, Short.MAX_VALUE));

		pack();
	}

	private void avoid() {
		this.dispose();
	}

	private void go(ActionEvent evt) {
		int n = (int) (Math.random() * 6) + 1;
		this.startButton.setIcon(new ImageIcon(getClass().getResource(String.format("/image/number/%d.jpg", n))));
		/* ��ԭ������ͼ��icon */
		if (location[people] == 0) {
			label[location[people]].setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/���.jpg")));
		} else if (location[people] == 4 || location[people] == 37) {
			label[location[people]].setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/ҽԺ.jpg")));
		} else if (location[people] == 6 || location[people] == 32) {
			label[location[people]].setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/���.jpg")));
		} else if (location[people] == 9 || location[people] == 25) {
			label[location[people]].setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/����.jpg")));
		} else if (location[people] == 12 || location[people] == 21) {
			label[location[people]].setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/��Ʒ.jpg")));
		} else if (location[people] == 15 || location[people] == 22) {
			label[location[people]].setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/����.jpg")));
		} else if (location[people] == 28) {
			label[location[people]].setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/ħ��.jpg")));
		} else {
			label[location[people]].setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/�յ�.jpg")));
		}
		/* λ�øı� */
		location[people] += n;
		if (location[people] >= 40) {
			location[people] -= 40;
		}
		/* ��õ�ǰ��ͼλ�õ���Ϣ */
		String place = "";
		try {
			Icon icon = label[location[people]].getIcon();
			String result = java.net.URLDecoder.decode(icon.toString(), "utf-8");
			Pattern pattern = Pattern.compile("bin/img/(.*?).jpg");
			Matcher matcher = pattern.matcher(result);
			if (matcher.find()) {
				place = matcher.group(0).replace("bin/img/", "").replace(".jpg", "");
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		/* ��ͼ���ܴ��� */
		label[location[people]].setIcon(new javax.swing.ImageIcon(
				getClass().getResource(String.format("/image/person/%s(map).jpg", personList[people]))));
		if (place.equals("ҽԺ")) {
			goHospital(2);
		} else if (place.equals("���")) {
			JOptionPane.showMessageDialog(null, "·����أ����100������");
			cardNumber[people] += 100;
			cardNumberField.setText(Integer.toString(cardNumber[people]));
		} else if (place.equals("����")) {
			int choose = (int) (Math.random() * 4) + 1;
			if (choose == 1) {
				JOptionPane.showMessageDialog(null, "��ϲ�㣡���·�Ͽ�һ��");
				cardButton2.setText(Integer.toString(Integer.valueOf(cardButton2.getText()) + 1));
			} else if (choose == 2) {
				JOptionPane.showMessageDialog(null, "��ϲ�㣡���ը����һ��");
				cardButton7.setText(Integer.toString(Integer.valueOf(cardButton7.getText()) + 1));
			} else if (choose == 3) {
				JOptionPane.showMessageDialog(null, "��ϲ�㣡���ͣ����һ��");
				cardButton1.setText(Integer.toString(Integer.valueOf(cardButton1.getText()) + 1));
			} else if (choose == 4) {
				JOptionPane.showMessageDialog(null, "��ϲ�㣡��û���������һ��");
				cardButton3.setText(Integer.toString(Integer.valueOf(cardButton3.getText()) + 1));
			}
			/* if end */
		} else if (place.equals("��Ʒ")) {
			int choose = (int) (Math.random() * 4) + 1;
			if (choose == 1) {
				JOptionPane.showMessageDialog(null, "��ϲ�㣡����ʽ�2000");
				addMoney(2000);
			} else if (choose == 2) {
				JOptionPane.showMessageDialog(null, "��ϲ�㣡��ÿ�����200");
				cardNumber[people] += 200;
				cardNumberField.setText(Integer.toString(this.cardNumber[people]));
			} else if (choose == 3) {
				JOptionPane.showMessageDialog(null, "��ϲ�㣡��ò���һ��");
				cardButton5.setText(Integer.toString(Integer.valueOf(cardButton5.getText()) + 1));
			} else if (choose == 4) {
				JOptionPane.showMessageDialog(null, "��ϲ�㣡��÷���������һ��");
				cardButton6.setText(Integer.toString(Integer.valueOf(cardButton6.getText()) + 1));
			}
			/* if end */
		} else if (place.equals("����")) {
			JOptionPane.showMessageDialog(null, "·������������3�죬��ʧ500Ԫ");
			JOptionPane.showMessageDialog(null, "����2��");
			JOptionPane.showMessageDialog(null, "����1��");
			reduceMoney(500);
		} else if (place.equals("ħ��")) {
			int choose = (int) (Math.random() * 2) + 1;
			if (choose == 1) {
				JOptionPane.showMessageDialog(null, "��ϲ�㣡���˥��һ��");
				cardButton9.setText(Integer.toString(Integer.valueOf(cardButton9.getText()) + 1));
			} else if (choose == 2) {
				JOptionPane.showMessageDialog(null, "��ϲ�㣡��÷��ݽ�����һ��");
				cardButton3.setText(Integer.toString(Integer.valueOf(cardButton3.getText()) + 1));
			}
			/* if end */
		}
		/* ������ͼBuffer */
		if (label[location[people]].getText() == "·��") {
			JOptionPane.showMessageDialog(null, "����·�ϣ���Ϣһ��");
		} else if (label[location[people]].getText() == "����") {
			JOptionPane.showMessageDialog(null, "��������Ǯ��+2000");
			addMoney(2000);
		} else if (label[location[people]].getText() == "˥��") {
			JOptionPane.showMessageDialog(null, "����˥��Ǯ��-2000");
			reduceMoney(2000);
		} else if (label[location[people]].getText() == "����") {
			JOptionPane.showMessageDialog(null, "·����������˰1000");
			addMoney(1000);
		} else if (label[location[people]].getText() == "ը��") {
			JOptionPane.showMessageDialog(null, "����ը����סԺ����");
			goHospital(3);
		}
		if (money[people] < 0) {
			int res = JOptionPane.showConfirmDialog(null, String.format("��Ϸ������%s��ʤ", personList[(people - 1) % 2]),
					"��Ϸ����", JOptionPane.YES_NO_OPTION);
			if (res == JOptionPane.YES_OPTION) {
				new ChooseUserNumber().setVisible(true);
			} else {
				new ChooseWay().setVisible(true);
			}
			this.dispose();
		}
		changeUser();
	}

	/* ������ɫ */
	public void changeUser() {
		/* �ռ���ǰ��ɫ�Ŀ�Ƭ���� */
		for (int i = 0; i < 9; i++) {
			card[people][i] = Integer.valueOf(cardButton[i].getText());
		}
		/* peopleֵ���� */
		if (people == 1) {
			people = 0;
		} else {
			people = 1;
		}
		/* �û�������ʾ */
		moneyField.setText(Integer.toString(money[people]));
		cardNumberField.setText(Integer.toString(cardNumber[people]));
		roomNumberField.setText(Integer.toString(roomNumber[people]));
		textField.setText(personList[people]);
		/* ��Ƭ�������� */
		for (int i = 0; i < 9; i++) {
			cardButton[i].setText(Integer.toString(card[people][i]));
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		/* ��Ƭ�������� */
		Object event = e.getSource();
		for (int i = 0, len = cardButton.length; i < len; i++) {
			if (event.equals(cardButton[i])) {
				int number = Integer.valueOf(cardButton[i].getText());
				if (number <= 0) {
					JOptionPane.showMessageDialog(null, "����������");
				} else {
					cardButton[i].setText(Integer.toString(number - 1));
					cardEvent(event);
				}
			}
		}
	}

	/** ��Ƭ�¼� **/
	public void cardEvent(Object event) {
		if (event.equals(cardButton1)) {
			JOptionPane.showMessageDialog(null, "ʹ��ͣ������ֹͣһ����");
			JOptionPane.showMessageDialog(null, "ֹͣһ��");
		} else if (event.equals(cardButton2)) {
			JOptionPane.showMessageDialog(null, "ʹ��·�Ͽ�������·�ϣ�");
			label[(location[people] + 5) % 40].setText("·��");
		} else if (event.equals(cardButton3)) {
			JOptionPane.showMessageDialog(null, "ʹ�÷��ݽ�������������ǰλ�÷��ݣ�");
			if (label[location[people]].getText() == "����") {
				label[location[people]].setText("");
				reduceRoomNumber(1);
			} else {
				JOptionPane.showMessageDialog(null, "��ǰλ��û�з��ݣ�");
			}
		} else if (event.equals(cardButton4)) {
			JOptionPane.showMessageDialog(null, "ʹ�û������޿������ǰ5��λ�������ϰ���");
			for (int i = 0; i < 5; i++) {
				if (label[location[people] + i].getText() == "ը��" || label[location[people] + i].getText() == "·��") {
					label[location[people] + i].setText("");
				}
			}
		} else if (event.equals(cardButton5)) {
			JOptionPane.showMessageDialog(null, "ʹ�ò��񿨣����ɲ���");
			label[(location[people] + 5) % 40].setText("����");
		} else if (event.equals(cardButton6)) {
			JOptionPane.showMessageDialog(null, "ʹ�÷������������ڵ�ǰλ�����ɷ��ݣ�");
			if (label[location[people]].getText() == "����") {
				JOptionPane.showMessageDialog(null, "��ǰλ�����з��ݣ�");
			} else {
				addRoomNumber(1);
				label[location[people]].setText("����");
			}
		} else if (event.equals(cardButton7)) {
			JOptionPane.showMessageDialog(null, "ʹ��ը����������ը����");
			label[(location[people] + 5) % 40].setText("ը��");
		} else if (event.equals(cardButton8)) {
			JOptionPane.showMessageDialog(null, "ʹ�����ʿ���Ǯ��+2000��");
			addMoney(2000);
		} else if (event.equals(cardButton9)) {
			JOptionPane.showMessageDialog(null, "ʹ��˥�񿨣�����˥��");
			label[(location[people] + 5) % 40].setText("˥��");
		}
	}

	/** ��ͼλ���¼� **/
	public void goHospital(int number) {
		JOptionPane.showMessageDialog(null, String.format("סԺ%d�죬����%dԪ", number, number * 300));
		reduceMoney(number * 300);
		for (int i = number - 1; i > 0; i--) {
			JOptionPane.showMessageDialog(null, String.format("����%d�죡", i));
		}
	}

	/** �������Ը��� **/
	public void addMoney(int number) {
		money[people] += number;
		moneyField.setText(Integer.toString(this.money[people]));
	}

	public void reduceMoney(int number) {
		money[people] -= number;
		moneyField.setText(Integer.toString(this.money[people]));
	}

	public void addCardNumber(int number) {
		cardNumber[people] += number;
		moneyField.setText(Integer.toString(this.cardNumber[people]));
	}

	public void reduceCardNumber(int number) {
		cardNumber[people] -= number;
		moneyField.setText(Integer.toString(this.cardNumber[people]));
	}

	public void addRoomNumber(int number) {
		roomNumber[people] += number;
		moneyField.setText(Integer.toString(this.roomNumber[people]));
	}

	public void reduceRoomNumber(int number) {
		roomNumber[people] -= number;
		moneyField.setText(Integer.toString(this.roomNumber[people]));
	}

	/** �˵��¼����� **/
	public class meunEvent implements ActionListener {
		public void actionPerformed(ActionEvent evt) {
			Object e = evt.getSource();
			if (e.equals(menuButton1)) {
				new MyMessage().setVisible(true);
			} else if (e.equals(menuButton2)) {
				new GameRule().setVisible(true);
			} else if (e.equals(menuButton3)) {
				new GameRole().setVisible(true);
			} else if (e.equals(menuButton4)) {
				new GameCard().setVisible(true);
			} else if (e.equals(menuButton5)) {
				new ChooseLoginWay().setVisible(true);
				avoid();
			} else if (e.equals(menuButton6)) {
				new ChooseWay().setVisible(true);
				avoid();
			} else if (e.equals(menuButton7)) {
				System.exit(0);
			}
		}
	}

}