package game;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import style.SetSwing;
import java.awt.Panel;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.GridLayout;
import java.awt.Button;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ChooseUserNumber extends JFrame implements MouseListener {
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private Panel panel_1;
	private Panel panel;
	private Panel panel_2;
	private JLabel label1;
	private JLabel person11;
	private JLabel person12;
	private JLabel person13;
	private JLabel person14;
	private JLabel label15;
	private JLabel label2;
	private JLabel person21;
	private JLabel person22;
	private JLabel person23;
	private JLabel person24;
	private JLabel label25;
	public String[] personList = { "", "" };
	private Panel panel_3;
	private Button button;

	public static void main(String[] args) {
		new ChooseUserNumber().setVisible(true);
	}

	private void avoid() {
		this.dispose();
	}

	public ChooseUserNumber() {
		setTitle("\u9009\u62E9\u6E38\u620F\u89D2\u8272");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(420, 240, 520, 280);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		/* ��ɫѡ�� */
		panel_1 = new Panel();
		contentPane.add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(new GridLayout(3, 0, 0, 0));
		/* ��ɫ1 */
		panel = new Panel();
		label1 = new JLabel("��1����ɫ��");
		panel.add(label1);
		person11 = new SetSwing().getPersonButton("�𱴱�");
		person11.addMouseListener(this);
		panel.add(person11);
		person12 = new SetSwing().getPersonButton("��С��");
		person12.addMouseListener(this);
		panel.add(person12);
		person13 = new SetSwing().getPersonButton("������");
		person13.addMouseListener(this);
		panel.add(person13);
		person14 = new SetSwing().getPersonButton("ɳ¡��˹");
		person14.addMouseListener(this);
		panel.add(person14);
		label15 = new JLabel("\u89D2\u8272\u540D\uFF1A");
		panel.add(label15);
		panel_1.add(panel);
		/* ��ɫ2 */
		panel_2 = new Panel();
		label2 = new JLabel("��2����ɫ��");
		panel_2.add(label2);
		person21 = new SetSwing().getPersonButton("�𱴱�");
		person21.addMouseListener(this);
		panel_2.add(person21);
		person22 = new SetSwing().getPersonButton("��С��");
		person22.addMouseListener(this);
		panel_2.add(person22);
		person23 = new SetSwing().getPersonButton("������");
		person23.addMouseListener(this);
		panel_2.add(person23);
		person24 = new SetSwing().getPersonButton("ɳ¡��˹");
		person24.addMouseListener(this);
		panel_2.add(person24);
		label25 = new JLabel("\u89D2\u8272\u540D\uFF1A");
		panel_2.add(label25);
		panel_1.add(panel_2);

		panel_3 = new Panel();
		panel_1.add(panel_3);

		button = new Button("\u5F00\u59CB\u6E38\u620F");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (personList[0].equals("") || personList[1].equals("")) {
					JOptionPane.showMessageDialog(null, "��ѡ���ɫ");
				} else if (personList[0].equals(personList[1])) {
					JOptionPane.showMessageDialog(null, "������ɫ��������ͬ");
				} else {
					new GameStart3(personList).setVisible(true);
					avoid();
				}
			}
		});
		panel_3.add(button);
		JLabel versionLable = new JLabel("Version.2019.1.2");
		versionLable.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(versionLable, BorderLayout.SOUTH);

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		Object event = e.getSource();
		if (event.equals(person11)) {
			personList[0] = "�𱴱�";
		} else if (event.equals(person12)) {
			personList[0] = "��С��";
		} else if (event.equals(person13)) {
			personList[0] = "������";
		} else if (event.equals(person14)) {
			personList[0] = "ɳ¡��˹";
		} else if (event.equals(person21)) {
			personList[1] = "�𱴱�";
		} else if (event.equals(person22)) {
			personList[1] = "��С��";
		} else if (event.equals(person23)) {
			personList[1] = "������";
		} else if (event.equals(person24)) {
			personList[1] = "ɳ¡��˹";
		}
		label15.setText(String.format("��ѡ���ɫ��%s", personList[0]));
		label25.setText(String.format("��ѡ���ɫ��%s", personList[1]));
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

}
