package login;

import java.awt.event.ActionListener;

import game.ChooseUserNumber;
import game.GameStart1;
import game.GameStart2;

import java.awt.event.ActionEvent;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;
import javax.swing.LayoutStyle.ComponentPlacement;

public class ChooseWay extends javax.swing.JFrame {
	private static final long serialVersionUID = 1L;
	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton2;
	private javax.swing.JButton jButton3;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JPanel jPanel1;

	private void avoid() {
		this.dispose();
	}

	public ChooseWay() {
		this.setBounds(560, 200, 0, 0);
		jPanel1 = new javax.swing.JPanel();
		jLabel1 = new javax.swing.JLabel();
		jButton1 = new javax.swing.JButton();
		jButton1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new GameStart2().setVisible(true);
				avoid();
			}
		});
		jLabel2 = new javax.swing.JLabel();
		jButton2 = new javax.swing.JButton();
		jButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new GameStart1().setVisible(true);
				avoid();
			}
		});
		jButton3 = new javax.swing.JButton();
		jButton3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ChooseLoginWay().setVisible(true);
				avoid();
			}
		});

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jPanel1.setBackground(new java.awt.Color(232, 232, 251));

		jLabel1.setBackground(new java.awt.Color(232, 232, 251));
		jLabel1.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jLabel1.setText("\u6b22\u8fce\u8fdb\u5165\uff01");

		jButton1.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jButton1.setText("\u5355 \u673a \u6a21 \u5f0f");

		jLabel2.setBackground(new java.awt.Color(232, 232, 251));
		jLabel2.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jLabel2.setText("\u8bf7\u9009\u62e9\u6e38\u620f\u5f00\u59cb\u6a21\u5f0f\uff1a");

		jButton2.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jButton2.setText("\u7f51 \u7edc \u6a21 \u5f0f");

		jButton3.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jButton3.setText("\u8fd4\u56de");

		JButton button = new JButton();
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ChooseUserNumber().setVisible(true);
				avoid();
			}
		});
		button.setText("\u53CC \u4EBA \u6A21 \u5F0F");
		button.setFont(new Font("Dialog", Font.BOLD, 18));

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
		jPanel1Layout.setHorizontalGroup(
			jPanel1Layout.createParallelGroup(Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup()
					.addContainerGap()
					.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
						.addComponent(jLabel1)
						.addComponent(jLabel2))
					.addContainerGap(41, Short.MAX_VALUE))
				.addGroup(jPanel1Layout.createSequentialGroup()
					.addContainerGap(148, Short.MAX_VALUE)
					.addComponent(jButton3)
					.addGap(22))
				.addGroup(jPanel1Layout.createSequentialGroup()
					.addGap(56)
					.addGroup(jPanel1Layout.createParallelGroup(Alignment.TRAILING, false)
						.addComponent(jButton2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(jButton1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(button, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
					.addContainerGap(62, Short.MAX_VALUE))
		);
		jPanel1Layout.setVerticalGroup(
			jPanel1Layout.createParallelGroup(Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup()
					.addContainerGap()
					.addComponent(jLabel1)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(jLabel2)
					.addGap(34)
					.addComponent(jButton1)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(button, GroupLayout.PREFERRED_SIZE, 35, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(jButton2)
					.addPreferredGap(ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
					.addComponent(jButton3)
					.addContainerGap())
		);
		jPanel1.setLayout(jPanel1Layout);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.PREFERRED_SIZE));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.PREFERRED_SIZE));

		pack();
	}
}