package login;

import javax.swing.JFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;

public class ChooseLoginWay extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton2;
	private javax.swing.JButton jButton3;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JPanel jPanel1;

	public static void main(String[] args) {
		new ChooseLoginWay().setVisible(true);
	}

	public ChooseLoginWay() {
		setTitle("\u8BF7\u9009\u62E9\u767B\u5F55\u65B9\u5F0F");
		setBounds(530, 200, 0, 0);
		jPanel1 = new javax.swing.JPanel();
		jLabel1 = new javax.swing.JLabel();
		jButton1 = new javax.swing.JButton();
		jButton2 = new javax.swing.JButton();
		jButton3 = new javax.swing.JButton();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jPanel1.setBackground(new java.awt.Color(232, 232, 251));

		jLabel1.setIcon(new ImageIcon(ChooseLoginWay.class.getResource("/image/login/\u8BF7\u767B\u5F55.PNG"))); // NOI18N

		jButton1.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jButton1.setText("\u8d26 \u53f7 \u5bc6 \u7801 \u767b \u5f55");
		jButton1.addActionListener(this);

		jButton2.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jButton2.setText("\u5fae \u4fe1 \u5feb \u901f \u767b \u5f55");
		jButton2.addActionListener(this);

		jButton3.setBackground(new java.awt.Color(232, 232, 251));
		jButton3.setFont(new java.awt.Font("���Ŀ���", 1, 16));
		jButton3.setText("\u9000\u51fa");
		jButton3.addActionListener(this);

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout
						.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(jPanel1Layout.createSequentialGroup().addGap(49, 49, 49).addComponent(jLabel1))
						.addGroup(jPanel1Layout.createSequentialGroup().addContainerGap()
								.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING,
												javax.swing.GroupLayout.DEFAULT_SIZE, 277, Short.MAX_VALUE)
										.addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, 277,
												Short.MAX_VALUE)))
						.addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
								.addContainerGap(222, Short.MAX_VALUE).addComponent(jButton3)))
						.addContainerGap()));
		jPanel1Layout
				.setVerticalGroup(
						jPanel1Layout
								.createParallelGroup(
										javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(jPanel1Layout.createSequentialGroup().addGap(24, 24, 24)
										.addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(38, 38, 38)
										.addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 43,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(31, 31, 31)
										.addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 42,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34,
												Short.MAX_VALUE)
										.addComponent(jButton3).addContainerGap()));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.PREFERRED_SIZE));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		pack();
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		Object e = event.getSource();
		if (e.equals(jButton1)) {
			// �ʺż������¼
			new LoginWay1().setVisible(true);
			this.dispose();
		} else if (e.equals(jButton2)) {
			new LoginWay2().setVisible(true);
			this.dispose();
		} else if (e.equals(jButton3)) {
			// �˳�ϵͳ
			System.exit(0);
		}

	}
}