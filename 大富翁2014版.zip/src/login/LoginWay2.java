package login;

import javax.swing.JFrame;

public class LoginWay2 extends JFrame {

	private static final long serialVersionUID = 1L;
	private javax.swing.JButton jButton3;
	private javax.swing.JButton jButton4;
	private javax.swing.JButton jButton6;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JPanel jPanel1;

	private void avoid() {
		this.dispose();
	}

	public LoginWay2() {
		setBounds(500, 150, 0, 0);
		jPanel1 = new javax.swing.JPanel();
		jLabel3 = new javax.swing.JLabel();
		jLabel5 = new javax.swing.JLabel();
		jLabel4 = new javax.swing.JLabel();
		jLabel2 = new javax.swing.JLabel();
		jLabel1 = new javax.swing.JLabel();
		jButton3 = new javax.swing.JButton();
		jButton4 = new javax.swing.JButton();
		jButton6 = new javax.swing.JButton();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jPanel1.setBackground(new java.awt.Color(232, 232, 251));

		jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/��ά��.PNG"))); // NOI18N

		jLabel5.setBackground(new java.awt.Color(215, 230, 215));
		jLabel5.setFont(new java.awt.Font("���Ŀ���", 0, 14));
		jLabel5.setText("\u626b\u7801\u767b\u5f55");

		jLabel4.setBackground(new java.awt.Color(232, 232, 251));
		jLabel4.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jLabel4.setForeground(new java.awt.Color(0, 51, 204));
		jLabel4.setText("\u5fae \u4fe1");

		jLabel2.setBackground(new java.awt.Color(215, 230, 215));
		jLabel2.setFont(new java.awt.Font("���Ŀ���", 0, 14));
		jLabel2.setText("\u8bf7\u4f7f\u7528");

		jLabel1.setBackground(new java.awt.Color(215, 230, 215));
		jLabel1.setFont(new java.awt.Font("������", 1, 20));
		jLabel1.setText("\u626b \u4e00 \u626b \u767b \u5f55");

		jButton3.setBackground(new java.awt.Color(232, 232, 251));
		jButton3.setFont(new java.awt.Font("���Ŀ���", 0, 14));
		jButton3.setForeground(new java.awt.Color(0, 0, 204));
		jButton3.setText("\u8d26\u53f7\u5bc6\u7801\u767b\u5f55");
		jButton3.setBorder(null);
		jButton3.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				new LoginWay1().setVisible(true);
				avoid();
			}
		});

		jButton4.setBackground(new java.awt.Color(232, 232, 251));
		jButton4.setFont(new java.awt.Font("���Ŀ���", 0, 14));
		jButton4.setForeground(new java.awt.Color(0, 0, 204));
		jButton4.setText("\u7acb\u5373\u6ce8\u518c");
		jButton4.setBorder(null);
		jButton4.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				new LoginWay1().setVisible(true);
				avoid();
			}
		});

		jButton6.setBackground(new java.awt.Color(231, 231, 250));
		jButton6.setFont(new java.awt.Font("���Ŀ���", 1, 16));
		jButton6.setText("\u8fd4  \u56de");
		jButton6.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				new ChooseLoginWay().setVisible(true);
			}
		});

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup().addGap(51, 51, 51)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(jLabel1)
								.addGroup(jPanel1Layout.createSequentialGroup().addComponent(jLabel2)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(jLabel4)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(jLabel5)))
						.addContainerGap(41, Short.MAX_VALUE))
				.addGroup(jPanel1Layout.createSequentialGroup().addGap(25, 25, 25).addComponent(jLabel3)
						.addContainerGap(26, Short.MAX_VALUE))
				.addGroup(javax.swing.GroupLayout.Alignment.TRAILING,
						jPanel1Layout.createSequentialGroup().addContainerGap()
								.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
										.addComponent(jButton6)
										.addGroup(jPanel1Layout.createSequentialGroup()
												.addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 93,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 61,
														Short.MAX_VALUE)
												.addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 70,
														javax.swing.GroupLayout.PREFERRED_SIZE)))
								.addGap(27, 27, 27)));
		jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addComponent(jLabel1)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(jLabel2).addComponent(jLabel4).addComponent(jLabel5))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(jLabel3)
						.addGap(18, 18, 18)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(jButton3).addComponent(jButton4))
						.addGap(18, 18, 18).addComponent(jButton6)
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		pack();
	}

	public static void main(String args[]) {
		new LoginWay2().setVisible(true);
	}

}