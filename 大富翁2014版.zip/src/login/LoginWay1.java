package login;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.Scanner;
import javax.swing.JOptionPane;
import database.Mysql;
import gui.UserMessage;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LoginWay1 extends javax.swing.JFrame {
	private static final long serialVersionUID = 1L;
	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton2;
	private javax.swing.JButton jButton3;
	private javax.swing.JButton jButton4;
	private javax.swing.JButton jButton5;
	private javax.swing.JButton jButton6;
	private javax.swing.JCheckBox jCheckBox1;
	private javax.swing.JCheckBox jCheckBox2;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JLabel jLabel6;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JPanel jPanel3;
	private javax.swing.JPasswordField jPasswordField1;
	private javax.swing.JPasswordField jPasswordField2;
	private javax.swing.JTabbedPane jTabbedPane1;
	private javax.swing.JTextField jTextField1;
	private javax.swing.JTextField jTextField2;
	private javax.swing.JTextField jTextField3;
	private javax.swing.JTextField jTextField4;

	private void avoid() {
		this.dispose();
	}

	public LoginWay1() {
		setTitle("\u767B\u5F55");
		setBounds(400, 150, 0, 0);
		initComponents();
		this.rememberPw();
		this.jCheckBox2.setVisible(true);
		this.jPasswordField1.setEchoChar('*');
	}

	@SuppressWarnings("resource")
	private void rememberPw() {
		File f = new File("rem.txt");
		if (f.exists()) {
			try {
				Scanner sc = new Scanner(f);
				String name = sc.nextLine();
				String pw = sc.nextLine();
				this.jTextField1.setText(name);
				this.jPasswordField1.setText(decry(pw));
				this.jCheckBox1.setSelected(true);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}

		}

	}

	private String encry(String info) {
		// TODO Auto-generated method stub
		char[] c = info.toCharArray();
		String out = "";
		for (int i = 0; i < c.length; i++) {
			out += ((char) (c[i] + 5));
		}
		return out;
	}

	private String decry(String info) {
		// TODO Auto-generated method stub
		char[] c = info.toCharArray();
		String out = "";
		for (int i = 0; i < c.length; i++) {
			out += ((char) (c[i] - 5));
		}
		return out;

	}

	@SuppressWarnings("deprecation")
	private void addRemPw() {
		File f = new File("rem.txt");
		PrintWriter pw;
		try {
			pw = new PrintWriter(f);
			pw.println(this.jTextField1.getText());
			pw.println(encry(this.jPasswordField1.getText()));
			pw.flush();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void initComponents() {

		jPanel1 = new javax.swing.JPanel();
		jTabbedPane1 = new javax.swing.JTabbedPane();
		jPanel2 = new javax.swing.JPanel();
		jLabel1 = new javax.swing.JLabel();
		jLabel2 = new javax.swing.JLabel();
		jButton1 = new javax.swing.JButton();
		jButton1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new PasswordForget().setVisible(true);
				avoid();
			}
		});
		jTextField1 = new javax.swing.JTextField();
		jPasswordField1 = new javax.swing.JPasswordField();
		jButton2 = new javax.swing.JButton();
		jCheckBox1 = new javax.swing.JCheckBox();
		jPanel3 = new javax.swing.JPanel();
		jLabel3 = new javax.swing.JLabel();
		jTextField2 = new javax.swing.JTextField();
		jLabel4 = new javax.swing.JLabel();
		jPasswordField2 = new javax.swing.JPasswordField();
		jLabel5 = new javax.swing.JLabel();
		jTextField3 = new javax.swing.JTextField();
		jLabel6 = new javax.swing.JLabel();
		jTextField4 = new javax.swing.JTextField();
		jButton3 = new javax.swing.JButton();
		jButton4 = new javax.swing.JButton();
		jButton4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new UserMessage().setVisible(true);
			}
		});
		jButton5 = new javax.swing.JButton();
		jCheckBox2 = new javax.swing.JCheckBox();
		jButton6 = new javax.swing.JButton();
		jButton6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ChooseLoginWay().setVisible(true);
				avoid();
			}
		});

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jPanel1.setBackground(new java.awt.Color(232, 232, 251));

		jTabbedPane1.setBackground(new java.awt.Color(232, 232, 251));
		jTabbedPane1.setFont(new java.awt.Font("���Ŀ���", 1, 14));

		jPanel2.setBackground(new java.awt.Color(232, 232, 251));
		jPanel2.setFont(new java.awt.Font("���Ŀ���", 1, 14));

		jLabel1.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jLabel1.setText("\u7528 \u6237 \u540d\uff1a");

		jLabel2.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jLabel2.setText("\u5bc6     \u7801\uff1a");

		jButton1.setFont(new java.awt.Font("���Ŀ���", 1, 14));
		jButton1.setText("\u5fd8\u8bb0\u5bc6\u7801");

		jTextField1.setFont(new java.awt.Font("���Ŀ���", 0, 14));
		jTextField1.setForeground(new java.awt.Color(204, 204, 204));
		jTextField1.setText("\u7528\u6237\u540D");
		jTextField1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
		jTextField1.setMargin(new java.awt.Insets(0, 0, 0, 0));
		jTextField1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jTextField1ActionPerformed(evt);
			}
		});
		jTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyTyped(java.awt.event.KeyEvent evt) {
				jTextField1jTextFieldkeyTyped(evt);
			}
		});

		jPasswordField1.setFont(new java.awt.Font("����", 0, 14));
		jPasswordField1.setForeground(new java.awt.Color(204, 204, 204));
		jPasswordField1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
		jPasswordField1.setMargin(new java.awt.Insets(0, 0, 0, 0));
		jPasswordField1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jPasswordField1ActionPerformed(evt);
			}
		});
		jPasswordField1.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyTyped(java.awt.event.KeyEvent evt) {
				jPasswordField1jPasswordFieldkeyTyped(evt);
			}
		});

		jButton2.setBackground(new java.awt.Color(232, 232, 251));
		jButton2.setFont(new java.awt.Font("���Ŀ���", 1, 24));
		jButton2.setForeground(new java.awt.Color(153, 153, 0));
		jButton2.setText("\u767b     \u5f55");
		jButton2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton2ActionPerformed(evt);
			}
		});

		jCheckBox1.setFont(new java.awt.Font("���Ŀ���", 1, 14));
		jCheckBox1.setText("\u8bb0\u4f4f\u5bc6\u7801");

		javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
		jPanel2.setLayout(jPanel2Layout);
		jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel2Layout.createSequentialGroup().addGroup(jPanel2Layout
						.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
						.addGroup(jPanel2Layout.createSequentialGroup().addGap(77, 77, 77).addGroup(jPanel2Layout
								.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
								.addGroup(javax.swing.GroupLayout.Alignment.LEADING,
										jPanel2Layout.createSequentialGroup().addComponent(jLabel2)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(jPasswordField1, javax.swing.GroupLayout.DEFAULT_SIZE,
														130, Short.MAX_VALUE))
								.addGroup(jPanel2Layout.createSequentialGroup().addComponent(jCheckBox1)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 69,
												Short.MAX_VALUE)
										.addComponent(jButton1))
								.addComponent(jButton2, javax.swing.GroupLayout.Alignment.LEADING,
										javax.swing.GroupLayout.PREFERRED_SIZE, 238,
										javax.swing.GroupLayout.PREFERRED_SIZE))
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
						.addGroup(jPanel2Layout.createSequentialGroup().addGap(74, 74, 74).addComponent(jLabel1)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(jTextField1)))
						.addGap(85, 85, 85)));
		jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel2Layout.createSequentialGroup().addGap(59, 59, 59)
						.addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 34,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 37,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(18, 18, 18)
						.addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 28,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE, 34,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(27, 27, 27)
						.addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(jButton1).addComponent(jCheckBox1))
						.addGap(18, 18, 18).addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 34,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(93, Short.MAX_VALUE)));

		jTabbedPane1.addTab("\u5df2\u6709\u8d26\u53f7\u5bc6\u7801\u767b\u5f55", jPanel2);

		jPanel3.setBackground(new java.awt.Color(232, 232, 251));
		jPanel3.setFont(new java.awt.Font("���Ŀ���", 1, 14));

		jLabel3.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jLabel3.setText("\u7528 \u6237 \u540d\uff1a");

		jTextField2.setFont(new java.awt.Font("΢���ź�", 0, 14));
		jTextField2.setForeground(new java.awt.Color(204, 204, 204));
		jTextField2.setText("\u624b\u673a/\u90ae\u7bb1/\u7528\u6237\u540d");
		jTextField2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
		jTextField2.setMargin(new java.awt.Insets(0, 0, 0, 0));

		jTextField2.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyTyped(java.awt.event.KeyEvent evt) {
				jTextField2jTextFieldkeyTyped(evt);
			}
		});

		jLabel4.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jLabel4.setText("\u5bc6     \u7801\uff1a");

		jPasswordField2.setFont(new java.awt.Font("����", 0, 14));
		jPasswordField2.setForeground(new java.awt.Color(204, 204, 204));
		jPasswordField2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
		jPasswordField2.setMargin(new java.awt.Insets(0, 0, 0, 0));
		jPasswordField2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jPasswordField2ActionPerformed(evt);
			}
		});
		jPasswordField2.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyTyped(java.awt.event.KeyEvent evt) {
				jPasswordField2jPasswordFieldkeyTyped(evt);
			}
		});

		jLabel5.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jLabel5.setText("\u90ae     \u7bb1\uff1a");

		jLabel6.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jLabel6.setText("\u9a8c \u8bc1 \u7801\uff1a");

		jButton3.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jButton3.setText("\u83b7\u53d6\u90ae\u7bb1\u9a8c\u8bc1\u7801");

		jButton4.setFont(new java.awt.Font("���Ŀ���", 1, 14));
		jButton4.setText("\u534f \u8bae");

		jButton5.setBackground(new java.awt.Color(231, 231, 250));
		jButton5.setFont(new java.awt.Font("���Ŀ���", 1, 24));
		jButton5.setForeground(new java.awt.Color(153, 153, 0));
		jButton5.setText("\u6ce8     \u518c");
		jButton5.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton5ActionPerformed(evt);
			}
		});

		jCheckBox2.setFont(new java.awt.Font("���Ŀ���", 1, 14));
		jCheckBox2.setText("\u9605\u8bfb\u5e76\u540c\u610f\u6211\u65b9\u534f\u8bae");

		javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
		jPanel3.setLayout(jPanel3Layout);
		jPanel3Layout
				.setHorizontalGroup(
						jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(jPanel3Layout.createSequentialGroup()
										.addGroup(jPanel3Layout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
												.addGroup(jPanel3Layout.createSequentialGroup().addGap(26, 26, 26)
														.addComponent(
																jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
												.addGroup(jPanel3Layout.createSequentialGroup().addContainerGap()
														.addGroup(jPanel3Layout
																.createParallelGroup(
																		javax.swing.GroupLayout.Alignment.LEADING,
																		false)
																.addComponent(
																		jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE,
																		javax.swing.GroupLayout.DEFAULT_SIZE,
																		Short.MAX_VALUE)
																.addComponent(
																		jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE,
																		javax.swing.GroupLayout.DEFAULT_SIZE,
																		Short.MAX_VALUE)
																.addComponent(jLabel6))))
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(jPanel3Layout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addGroup(jPanel3Layout.createSequentialGroup()
														.addComponent(jTextField4,
																javax.swing.GroupLayout.PREFERRED_SIZE, 98,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addPreferredGap(
																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
														.addComponent(jButton3))
												.addGroup(jPanel3Layout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
														.addComponent(jPasswordField2,
																javax.swing.GroupLayout.Alignment.LEADING,
																javax.swing.GroupLayout.DEFAULT_SIZE, 270,
																Short.MAX_VALUE)
														.addComponent(jTextField2,
																javax.swing.GroupLayout.Alignment.LEADING,
																javax.swing.GroupLayout.DEFAULT_SIZE, 270,
																Short.MAX_VALUE)
														.addComponent(jTextField3,
																javax.swing.GroupLayout.Alignment.LEADING,
																javax.swing.GroupLayout.DEFAULT_SIZE, 270,
																Short.MAX_VALUE)))
										.addGap(74, 74, 74))
								.addGroup(jPanel3Layout.createSequentialGroup().addGap(70, 70, 70)
										.addComponent(jCheckBox2).addGap(26, 26, 26).addComponent(jButton4)
										.addContainerGap(73, Short.MAX_VALUE))
								.addGroup(jPanel3Layout.createSequentialGroup().addGap(59, 59, 59)
										.addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 289,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addContainerGap(49, Short.MAX_VALUE)));
		jPanel3Layout.setVerticalGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel3Layout.createSequentialGroup().addGap(40, 40, 40).addGroup(jPanel3Layout
						.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 34,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGroup(jPanel3Layout.createSequentialGroup()
								.addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 37,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGap(21, 21, 21)
								.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 28,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(jPasswordField2, javax.swing.GroupLayout.PREFERRED_SIZE, 34,
												javax.swing.GroupLayout.PREFERRED_SIZE))))
						.addGap(18, 18, 18)
						.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 33,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 36,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(18, 18, 18)
						.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(jLabel6)
								.addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 33,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 35,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(18, 18, 18)
						.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(jButton4).addComponent(jCheckBox2))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(jButton5,
								javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGap(21, 21, 21)));

		jTabbedPane1.addTab("\u6ce8\u518c", jPanel3);

		jButton6.setBackground(new java.awt.Color(231, 231, 250));
		jButton6.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jButton6.setText("\u8fd4  \u56de");

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup().addContainerGap()
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(jTabbedPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 402, Short.MAX_VALUE)
								.addComponent(jButton6, javax.swing.GroupLayout.Alignment.TRAILING))
						.addContainerGap()));
		jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addComponent(jButton6)
						.addGap(20, 20, 20).addComponent(jTabbedPane1).addContainerGap()));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		pack();
	}

	private int login() {
		// ��½����
		Mysql mysql = new Mysql();
		String name = jTextField1.getText();
		String passwd = String.valueOf(jPasswordField1.getPassword());
		String sql = String.format("select UserPasswd from UserList where UserName='%S'", name);
		try {
			ResultSet rs = mysql.stmt.executeQuery(sql);
			while (rs.next()) {
				if (rs.getString("UserPasswd").equals(passwd)) {
					JOptionPane.showMessageDialog(null, "��½�ɹ�");
					return 1;
				} else {
					JOptionPane.showMessageDialog(null, "�������");
				}
			}
			JOptionPane.showMessageDialog(null, "�û������ڣ�");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
		if (login() == 1) {
			new ChooseWay().setVisible(true);
			this.dispose();
		}
		if (this.jCheckBox1.isSelected()) // ��¼�û���һ�ε��û���������
			addRemPw();
		else {
			File f = new File("rem.txt");
			if (f.exists()) {
				f.delete();
			}
		}
	}

	private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {
		// ע�Ṧ��
		if (jCheckBox2.isSelected()) {
			String name = jTextField2.getText();
			String passwd = String.valueOf(jPasswordField2.getPassword());
			String mail = jTextField3.getText();
			Mysql mysql = new Mysql();
			String sql = String.format("insert into UserList values(123,'%s','%s','%s',1,'1998-12-23','')", name,
					passwd, mail);
			try {
				mysql.stmt.executeUpdate(sql);
				JOptionPane.showMessageDialog(null, "ע��ɹ���");
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			JOptionPane.showMessageDialog(null, "����ͬ���û�Э��ſ�ע��");
		}
	}

	private void jPasswordField2jPasswordFieldkeyTyped(java.awt.event.KeyEvent evt) {
		// TODO add your handling code here:
	}

	private void jPasswordField2ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jTextField2jTextFieldkeyTyped(java.awt.event.KeyEvent evt) {
		// TODO add your handling code here:
	}

	@SuppressWarnings("deprecation")
	private void jPasswordField1jPasswordFieldkeyTyped(java.awt.event.KeyEvent evt) {
		if (this.jPasswordField1.getText().equals("����")) {
			this.jPasswordField1.setText("");
			this.jPasswordField1.setEchoChar('*');
		}
	}

	private void jPasswordField1ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jTextField1jTextFieldkeyTyped(java.awt.event.KeyEvent evt) {
		if (this.jTextField1.getText().equals("�ֻ�/����/�û���")) {
			this.jTextField1.setText("");
		}
	}

	private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}
}