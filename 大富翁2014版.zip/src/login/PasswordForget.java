package login;

import java.awt.Color;

import javax.swing.JOptionPane;

public class PasswordForget extends javax.swing.JFrame {

	private static final long serialVersionUID = 1L;
	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton2;
	private javax.swing.JButton jButton3;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JTextField jTextField1;
	private javax.swing.JTextField jTextField3;
	private javax.swing.JTextField jTextField4;

	public PasswordForget() {
		setBounds(480, 220, 0, 0);
		jPanel1 = new javax.swing.JPanel();
		jButton1 = new javax.swing.JButton();
		jButton3 = new javax.swing.JButton();
		jButton2 = new javax.swing.JButton();
		jTextField4 = new javax.swing.JTextField();
		jLabel3 = new javax.swing.JLabel();
		jTextField3 = new javax.swing.JTextField();
		jLabel2 = new javax.swing.JLabel();
		jTextField1 = new javax.swing.JTextField();
		jLabel1 = new javax.swing.JLabel();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jPanel1.setBackground(new java.awt.Color(232, 232, 251));

		jButton1.setBackground(new java.awt.Color(254, 254, 226));
		jButton1.setFont(new java.awt.Font("���Ŀ���", 0, 14));
		jButton1.setText("\u83b7\u53d6\u90ae\u7bb1\u9a8c\u8bc1\u7801");
		jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseEntered(java.awt.event.MouseEvent evt) {
				jButton1MouseEntered(evt);
			}
		});
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton1ActionPerformed(evt);
			}
		});

		jButton3.setBackground(new java.awt.Color(231, 231, 250));
		jButton3.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jButton3.setForeground(new java.awt.Color(0, 0, 204));
		jButton3.setText("\u9000\u51fa");
		jButton3.setBorder(null);
		jButton3.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton3ActionPerformed(evt);
			}
		});

		jButton2.setBackground(new java.awt.Color(231, 231, 250));
		jButton2.setFont(new java.awt.Font("���Ŀ���", 1, 24));
		jButton2.setForeground(new java.awt.Color(153, 153, 0));
		jButton2.setText("\u767b   \u5f55");
		jButton2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
		jButton2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton2ActionPerformed(evt);
			}
		});

		jTextField4.setFont(new java.awt.Font("���Ŀ���", 0, 18));
		jTextField4.setForeground(new java.awt.Color(204, 204, 204));
		jTextField4.setText("\u8bf7\u8f93\u5165\u9a8c\u8bc1\u7801");
		jTextField4.setBorder(javax.swing.BorderFactory.createEtchedBorder());
		jTextField4.setMargin(new java.awt.Insets(0, 0, 0, 0));
		jTextField4.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyTyped(java.awt.event.KeyEvent evt) {
				jTextField4jTextFieldkeyTyped(evt);
			}
		});

		jLabel3.setFont(new java.awt.Font("���Ŀ���", 1, 20));
		jLabel3.setText("\u9a8c\u8bc1\u7801");

		jTextField3.setFont(new java.awt.Font("���Ŀ���", 0, 18));
		jTextField3.setForeground(new java.awt.Color(204, 204, 204));
		jTextField3.setText("\u8bf7\u91cd\u65b0\u8bbe\u7f6e\u767b\u5f55\u5bc6\u7801");
		jTextField3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
		jTextField3.setMargin(new java.awt.Insets(0, 0, 0, 0));
		jTextField3.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyTyped(java.awt.event.KeyEvent evt) {
				jTextField3jTextFieldkeyTyped(evt);
			}
		});

		jLabel2.setFont(new java.awt.Font("���Ŀ���", 1, 20));
		jLabel2.setText("\u5bc6  \u7801");

		jTextField1.setFont(new java.awt.Font("���Ŀ���", 0, 18));
		jTextField1.setForeground(new java.awt.Color(204, 204, 204));
		jTextField1.setText("\u8bf7\u8f93\u5165\u90ae\u7bb1");
		jTextField1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
		jTextField1.setMargin(new java.awt.Insets(0, 0, 0, 0));
		jTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyTyped(java.awt.event.KeyEvent evt) {
				jTextField1jTextFieldkeyTyped(evt);
			}
		});

		jLabel1.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jLabel1.setText("\u90ae\u7bb1\u540d");

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addGroup(jPanel1Layout
						.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout
								.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(jButton3, javax.swing.GroupLayout.Alignment.TRAILING,
										javax.swing.GroupLayout.PREFERRED_SIZE, 40,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(jPanel1Layout.createSequentialGroup().addGroup(
										jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(jLabel2).addComponent(jLabel1).addComponent(jLabel3))
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(jPanel1Layout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout
														.createSequentialGroup()
														.addComponent(jTextField4, javax.swing.GroupLayout.DEFAULT_SIZE,
																130, Short.MAX_VALUE)
														.addPreferredGap(
																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
														.addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE,
																131, javax.swing.GroupLayout.PREFERRED_SIZE))
												.addComponent(jTextField3, javax.swing.GroupLayout.DEFAULT_SIZE, 268,
														Short.MAX_VALUE)
												.addComponent(jTextField1, javax.swing.GroupLayout.DEFAULT_SIZE, 268,
														Short.MAX_VALUE))))
								.addContainerGap())
						.addGroup(javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel1Layout.createSequentialGroup()
										.addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 217,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(61, 61, 61)))));
		jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup().addGap(30, 30, 30)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 36,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(jLabel1))
						.addGap(27, 27, 27)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 34,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(jLabel2))
						.addGap(29, 29, 29)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 36,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(jLabel3).addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE,
										31, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED).addComponent(jButton2)
						.addGap(18, 18, 18).addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 30,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(35, Short.MAX_VALUE)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		pack();
	}// </editor-fold>
		// GEN-END:initComponents

	private void jTextField1jTextFieldkeyTyped(java.awt.event.KeyEvent evt) {
		if (this.jTextField1.getText().equals("�ֻ�/����/�û���")) {
			this.jTextField1.setText("");
		}
	}

	private void jTextField3jTextFieldkeyTyped(java.awt.event.KeyEvent evt) {
		// TODO add your handling code here:
	}

	private void jTextField4jTextFieldkeyTyped(java.awt.event.KeyEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {

		new ChooseWay().setVisible(true);
		this.dispose();

	}

	private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {
		new ChooseLoginWay().setVisible(true);
		this.dispose();
	}

	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
		if (this.jButton1.getText().equals("��ȡ������֤��")) {
			JOptionPane.showMessageDialog(this, "���������ѷ�����������䣬��ע����գ�");
			this.dispose();
			new PasswordForget().setVisible(true);
			this.dispose();
		}
	}

	private void jButton1MouseEntered(java.awt.event.MouseEvent evt) {
		this.jButton1.setBackground(Color.LIGHT_GRAY);
	}

	public static void main(String args[]) {
		new PasswordForget().setVisible(true);
	}

}