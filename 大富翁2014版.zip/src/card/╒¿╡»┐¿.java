package card;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ը���� extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	public static void main(String[] args) {
		ը���� frame = new ը����();
		frame.setVisible(true);
	}

	public ը����() {
		setTitle("\u70B8\u5F39\u5361");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 342, 417);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel
				.setIcon(new ImageIcon(ը����.class.getResource("/image/card/\u70B8\u5F39\u5361\uFF08\u5927\uFF09.jpg")));
		lblNewLabel.setBounds(37, 27, 80, 93);
		contentPane.add(lblNewLabel);

		JLabel label = new JLabel("\u70B8\u5F39\u5361");
		label.setFont(new Font("����", Font.PLAIN, 20));
		label.setBounds(165, 63, 96, 24);
		contentPane.add(label);

		JLabel label_1 = new JLabel(
				"\u529F\u80FD\uFF1A\u5C06\u70B8\u5F39\u653E\u5728\u8DDD\u79BB\u5F53\u524D\u4F4D\u7F6E");
		label_1.setFont(new Font("����", Font.PLAIN, 20));
		label_1.setBounds(8, 154, 315, 23);
		contentPane.add(label_1);

		JLabel label_3 = new JLabel("\u5361\u70B9\u6570\uFF1A200");
		label_3.setFont(new Font("����", Font.PLAIN, 20));
		label_3.setBounds(11, 253, 140, 28);
		contentPane.add(label_3);

		JButton btnNewButton = new JButton("\u8FD4\u56DE");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				avoid();
			}
		});
		btnNewButton.setFont(new Font("����", Font.PLAIN, 20));
		btnNewButton.setBounds(205, 311, 93, 33);
		contentPane.add(btnNewButton);
		
		JLabel label_2 = new JLabel("5\u6B65\uFF0C\u73A9\u5BB6\u7ECF\u8FC7\u9700\u4F4F\u96622\u5929");
		label_2.setFont(new Font("����", Font.PLAIN, 20));
		label_2.setBounds(8, 187, 315, 23);
		contentPane.add(label_2);
	}

	public void avoid() {
		this.dispose();
	}
}
