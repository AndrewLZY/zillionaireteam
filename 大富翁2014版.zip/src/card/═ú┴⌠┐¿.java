package card;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ͣ���� extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	public static void main(String[] args) {
		ͣ���� frame = new ͣ����();
		frame.setVisible(true);
	}

	public ͣ����() {
		setTitle("\u505C\u7559\u5361");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 342, 417);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel
				.setIcon(new ImageIcon(ͣ����.class.getResource("/image/card/\u505C\u7559\u5361\uFF08\u5927\uFF09.jpg")));
		lblNewLabel.setBounds(37, 27, 80, 93);
		contentPane.add(lblNewLabel);

		JLabel label = new JLabel("\u505C\u7559\u5361");
		label.setFont(new Font("����", Font.PLAIN, 20));
		label.setBounds(165, 63, 96, 24);
		contentPane.add(label);

		JLabel label_1 = new JLabel(
				"\u529F\u80FD\uFF1A\u4F7F\u5BF9\u65B9\u505C\u7559\u5728\u539F\u4F4D\u7F6E\u4E00\u6B21");
		label_1.setFont(new Font("����", Font.PLAIN, 20));
		label_1.setBounds(8, 154, 315, 23);
		contentPane.add(label_1);

		JLabel label_3 = new JLabel("\u5361\u70B9\u6570\uFF1A100");
		label_3.setFont(new Font("����", Font.PLAIN, 20));
		label_3.setBounds(11, 253, 140, 28);
		contentPane.add(label_3);

		JButton btnNewButton = new JButton("\u8FD4\u56DE");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				avoid();
			}
		});
		btnNewButton.setFont(new Font("����", Font.PLAIN, 20));
		btnNewButton.setBounds(205, 311, 93, 33);
		contentPane.add(btnNewButton);
	}

	public void avoid() {
		this.dispose();
	}
}
