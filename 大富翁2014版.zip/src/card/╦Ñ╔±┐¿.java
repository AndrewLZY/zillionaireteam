package card;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ˥�� extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	public static void main(String[] args) {
		˥�� frame = new ˥��();
		frame.setVisible(true);
	}

	public ˥��() {
		setTitle("\u8870\u795E\u5361");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 342, 417);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel
				.setIcon(new ImageIcon(˥��.class.getResource("/image/card/\u8870\u795E\u5361\uFF08\u5927\uFF09.jpg")));
		lblNewLabel.setBounds(37, 27, 80, 93);
		contentPane.add(lblNewLabel);

		JLabel label = new JLabel("\u8870\u795E\u5361");
		label.setFont(new Font("����", Font.PLAIN, 20));
		label.setBounds(165, 63, 96, 24);
		contentPane.add(label);

		JLabel label_1 = new JLabel(
				"\u529F\u80FD\uFF1A\u8870\u795E\u9644\u8EAB\uFF0C\u8DEF\u8FC7\u5176\u4ED6\u73A9\u5BB6");
		label_1.setFont(new Font("����", Font.PLAIN, 20));
		label_1.setBounds(8, 154, 315, 23);
		contentPane.add(label_1);

		JLabel label_2 = new JLabel("\u7684\u5730\u4EA7\u65F6\u9700\u7F342\u500D\u8FC7\u8DEF\u8D39");
		label_2.setFont(new Font("����", Font.PLAIN, 20));
		label_2.setBounds(8, 193, 315, 23);
		contentPane.add(label_2);

		JLabel label_3 = new JLabel("\u5361\u70B9\u6570\uFF1A150");
		label_3.setFont(new Font("����", Font.PLAIN, 20));
		label_3.setBounds(11, 253, 140, 28);
		contentPane.add(label_3);

		JButton btnNewButton = new JButton("\u8FD4\u56DE");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				avoid();
			}
		});
		btnNewButton.setFont(new Font("����", Font.PLAIN, 20));
		btnNewButton.setBounds(205, 311, 93, 33);
		contentPane.add(btnNewButton);
	}

	public void avoid() {
		this.dispose();
	}
}
