package style;

/*�����ʽ*/
import javax.swing.JButton;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Font;

public class SetSwing {

	/* �˵���ť��ʽ */
	public JButton getMenuButton(String name) {
		JButton menuButton = new JButton(name);
		menuButton.setBackground(new java.awt.Color(232, 232, 251));
		menuButton.setFont(new java.awt.Font("���Ŀ���", 1, 16));
		return menuButton;
	}

	/* ��ͼ��ǩ��ʽ */
	public JLabel getMapLabel(String string) {
		JLabel label = new JLabel();
		label.setHorizontalTextPosition(JLabel.CENTER);
		label.setIcon(new javax.swing.ImageIcon(getClass().getResource(String.format("/img/%s.jpg", string))));
		label.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
		return label;
	}

	/* ���ﰴť��ʽ */
	public JLabel getPersonButton(String string) {
		JLabel label = new JLabel();
		label.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
		label.setIcon(new javax.swing.ImageIcon(getClass().getResource(String.format("/img/%s.jpg", string))));
		return label;
	}

	/* �������Ա�ǩ��ʽ */
	public JLabel getAttributeLabel(String string) {
		JLabel label = new JLabel(string);
		label.setFont(new Font("���Ŀ���", 1, 18));
		return label;
	}

	public JButton getCardButton() {
		JButton button = new JButton();
		button.setText("1");
		button.setFont(new Font("����", 1, 30));
		button.setForeground(new Color(128, 0, 0)); // CYAN
		button.setHorizontalTextPosition(JLabel.CENTER);
		button.setBackground(new java.awt.Color(204, 255, 204));
		button.setBackground(new java.awt.Color(204, 255, 204));
		return button;
	}

}
