package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Mysql {

	public String user = "root";
	public String password = "";
	public Connection connect = null;
	public Statement stmt = null;

	public Mysql() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connect = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/rich?useSSL=FALSE&serverTimezone=GMT&allowPublicKeyRetrieval=true",
					user, password);
			stmt = connect.createStatement();
		} catch (Exception e) {
			System.out.println("���ݿ�����ʧ�ܣ�");
		}
	}
}
