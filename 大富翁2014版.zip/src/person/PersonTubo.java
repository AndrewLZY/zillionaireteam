package person;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class PersonTubo extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JButton button;

	public static void main(String[] args) {
		PersonTubo frame = new PersonTubo();
		frame.setVisible(true);
	}

	public PersonTubo() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(PersonTubo.class.getResource("/image/person/\u963F\u571F\u4F2F.jpg")));
		setTitle("\u963F\u571F\u4F2F");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(475, 150, 400, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(
				new ImageIcon(PersonTubo.class.getResource("/image/person/\u963F\u571F\u4F2F\uFF08\u5927\uFF09.jpg")));
		lblNewLabel.setBounds(21, 10, 108, 146);
		contentPane.add(lblNewLabel);
		/* ������ */
		JLabel label = new JLabel("\u963F\u571F\u4F2F");
		label.setFont(new Font("����", Font.PLAIN, 20));
		label.setBounds(165, 43, 108, 24);
		contentPane.add(label);

		JLabel label_1 = new JLabel("\u4E2D\u56FD\uFF08\u53F0\u6E7E\uFF09");
		label_1.setFont(new Font("����", Font.PLAIN, 20));
		label_1.setBounds(165, 92, 153, 24);
		contentPane.add(label_1);
		/* ������Ϣ */
		String[] labelText = { "���գ�6��22��", "Ѫ�ͣ�O��", "���䣺70��", "���ߣ�158cm", "ְҵ���Ը�ũ", "��ͷ����̰�ƣ�̰�ƣ������к�����" };
		JLabel[] labelList = new JLabel[labelText.length];
		for (int i = 0; i < labelList.length; i++) {
			labelList[i] = new JLabel(labelText[i]);
			labelList[i].setFont(new Font("����", Font.PLAIN, 20));
			labelList[i].setBounds(20, 160 + 40 * i, 400, 25);
			contentPane.add(labelList[i]);
		}
		/* ȷ����ť */
		button = new JButton("\u786E\u5B9A");
		button.setFont(new Font("����", Font.PLAIN, 20));
		button.addActionListener(this);
		button.setBounds(257, 261, 93, 33);
		contentPane.add(button);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object event = e.getSource();
		if (event.equals(button)) {
			this.dispose();
		}
	}
}
