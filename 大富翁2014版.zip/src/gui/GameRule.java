package gui;
import javax.swing.JFrame;

public class GameRule extends javax.swing.JFrame {

	private static final long serialVersionUID = 1L;
	private javax.swing.JButton jButton1;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JTextArea jTextArea1;

	private void avoid() {
		this.dispose();
	}

	public GameRule() {
		setTitle("\u6E38\u620F\u89C4\u5219");
		setBounds(460, 140, 472, 453);
		jPanel1 = new javax.swing.JPanel();
		jScrollPane1 = new javax.swing.JScrollPane();
		jTextArea1 = new javax.swing.JTextArea();
		jLabel1 = new javax.swing.JLabel();
		jButton1 = new javax.swing.JButton();

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		jPanel1.setBackground(new java.awt.Color(232, 232, 251));

		jTextArea1.setBackground(new java.awt.Color(251, 251, 241));
		jTextArea1.setColumns(20);
		jTextArea1.setFont(new java.awt.Font("��������", 0, 14));
		jTextArea1.setRows(5);
		jTextArea1.setText(
				"\u4e00.\u57fa\u672c\u89c4\u5219  \u3000\u3000  \n\n1. \u6e38\u620f\u5f00\u59cb\u65f6\u6bcf\u4e2a\u73a9\u5bb6\u6301\u6709\u76f8\u540c\u7684\u521d\u59cb\u8d44\u91d1(\uffe52\uff0c5000)\n\u5361\u70b9\u6570\uff08200\uff09\u8fdb\u884c\u6e38\u620f\uff0c\u901a\u8fc7\u6bcf\u56de\u5408\u6295\u63b7\u9ab0\u5b50\u6765\u51b3\u5b9a\u524d\u8fdb\u7684\u683c\u6570\u3002    \n\n2. \u505c\u7559\u5728\u6ca1\u6709\u6301\u6709\u4eba\u7684\u7a7a\u5730\u65f6\u53ef\u4ee5\u6d88\u8d39\u4e00\u5b9a\u8d44\u91d1(\uffe52,500)\n\u6765\u8d2d\u4e70\u5730\u4ea7\uff0c\u5efa\u9020\u5c5e\u4e8e\u81ea\u5df1\u7684\u623f\u5b50\uff0c\u901a\u8fc7\u6e38\u620f\u5708\u6570\u589e\u52a0\u540e\u8fd8\n\u80fd\u591f\u5728\u5df2\u5efa\u9020\u623f\u4ea7\u4e0a\u5347\u7ea7\u81ea\u5df1\u7684\u623f\u5b50\u3002  \n\n3. \u5f53\u5bf9\u65b9\u73a9\u5bb6\u505c\u7559\u5728\u6211\u65b9\u6240\u6301\u6709\u5730\u4ea7\u4e0a\u65f6\u9700\u8981\u7f34\u4ed8\u4e00\u5b9a\u6570\u91cf\n\u7684\u8fc7\u8def\u8d39(\u521d\u7ea7\u623f\u9700\u7f34\uff1a\uffe5800\uff0c\u5347\u7ea7\u623f\u9700\u7f34\uff1a\uffe51200)\u3002   \u3000\u3000 \n\n4. \u5f53\u4e00\u65b9\u73b0\u91d1\u4f4e\u4e8e 0 \u4e07\u5143\u65f6\u73a9\u5bb6\u9677\u5165\u7834\u4ea7\u72b6\u6001(\u53ef\u4ee5\u7531\u5356\u5730\n\u4ea7\u6765\u6362\u53d6\u4e00\u5b9a\u7684\u8d44\u91d1)\uff0c \u9677\u5165\u7834\u4ea7\u72b6\u6001\u7684\u73a9\u5bb6\u6e38\u620f\u5931\u8d25\uff0c\u4e14\u5c5e\n\u4e8e\u5176\u7684\u5730\u4ea7\u5c06\u6e05\u96f6\u3002  \u3000\u3000  \n\n5. \u5176\u4ed6\u73a9\u5bb6\u7834\u4ea7\u540e\uff0c\u5269\u4f59\u6ca1\u6709\u7834\u4ea7\u7684\u73a9\u5bb6\u4e3a\u80dc\u8005\u3002     \n\n\u4e8c.\u5361\u7247\u89c4\u5219       \n\n1.\u6bcf\u5f20\u9053\u5177\u5361\u53ea\u80fd\u4f7f\u7528\u4e00\u6b21\uff0c\u4e14\u73a9\u5bb6\u6bcf\u4f7f\u7528\u4e00\u5f20\u9053\u5177\u5361\uff0c\u9700\u8981\n\u6d88\u8017\u4e0d\u7b49\u7684\u5361\u70b9\u6570  \n\n2.\u6b63\u5904\u4e8e\u67d0\u79cd\u72b6\u6001\u7684\u73a9\u5bb6\u6216\u5730\u683c\uff0c\u72b6\u6001\u6d88\u9664\u4e4b\u524d\uff0c\u4e0d\u80fd\u518d\u5bf9\u5176\n\u4f7f\u7528\u76f8\u540c\u7684\u9053\u5177;\u795e\u4ed9\u548c\u8870\u795e\u529f\u80fd\u9664\u5916\u3002   \n\n\u4e09.\u5404\u5361\u7247\u76f8\u5e94\u7684\u529f\u80fd   \n\n1.\u8def\u969c\u5361\uff1a\u73a9\u5bb6\u62e5\u6709\u540e\uff0c\u53ef\u5c06\u8def\u969c\u653e\u7f6e\u5230\u79bb\u5f53\u524d\u4f4d\u7f6e\u524d\u540e5\u6b65\u7684\n\u8ddd\u79bb\uff0c\u4efb\u4e00\u73a9\u5bb6\u7ecf\u8fc7\u90fd\u5c06\u88ab\u963b\u62e6\u5728\u5f53\u524d\u4f4d\u7f6e\u4e00\u4e2a\u56de\u5408 \uff0c\u9700\u6d88\u8017\n100\u5361\u70b9\u6570 \n\n2.\u70b8\u5f39\u5361\uff1a\u53ef\u5c06\u70b8\u5f39\u653e\u7f6e\u5230\u79bb\u5f53\u524d\u4f4d\u7f6e\u524d\u540e5\u6b65\u7684\u8ddd\u79bb\uff0c\u4efb\u4e00\u73a9\n\u5bb6\u7ecf\u8fc7\u90fd\u5c06\u88ab\u70b8\u4f24\uff0c\u9700\u4f4f\u96622\u5929\uff0c\u5373\u4e24\u4e2a\u56de\u5408\u5185\u4e0d\u80fd\u52a8 \uff0c\u9700\u6d88\u8017\n100\u5361\u70b9\u6570 \n\n3.\u673a\u5668\u5a03\u5a03\uff1a\u4f7f\u7528\u8be5\u9053\u5177\u53ef\u6e05\u626b\u524d\u65b9\u8def\u9762\u4e0a5\u6b65\u5185\u7684\u5176\u4ed6\u9053\u5177\uff0c\u9700\n\u6d88\u8017100\u5361\u70b9\u6570  \n\n4.\u505c\u7559\u5361\uff1a\u53ef\u4f7f\u5176\u4ed6\u73a9\u5bb6\u539f\u5730\u505c\u7559\u4e00\u56de\u5408\uff0c\u9700\u6d88\u8017100\u5361\u70b9\u6570   \n\n5.\u8d22\u795e\u5361\uff1a\u8d22\u795e\u9644\u8eab\uff0c\u8def\u8fc7\u5176\u4ed6\u73a9\u5bb6\u7684\u5730\u4ea7\u65f6\u4e0d\u9700\u7f34\u8d39\uff0c2\u8f6e\u5185\n  \u6709\u6548\uff0c\u9700\u6d88\u8017150\u5361\u70b9\u6570   \n\n6.\u8870\u795e\u5361\uff1a\u4f7f\u88ab\u9644\u8eab\u8005\u8def\u8fc7\u5176\u4ed6\u73a9\u5bb6\u5730\u4ea7\u65f6\uff0c\u9700\u7f342\u500d\u7684\u8fc7\u8def\u8d39\uff0c\n   \u9700\u6d88\u8017150\u5361\u70b9\u6570   \n\n7.\u589e\u8d44\u5361\uff1a\u5956\u52b1\u8d44\u91d1\uffe52000\uff0c\u9700\u6d88\u8017200\u5361\u70b9\u6570   \n\n8.\u623f\u5c4b\u5347\u7ea7\u5361\uff1a\u53ef\u4f7f\u81ea\u5df1\u7684\u4efb\u4e00\u5730\u4ea7\u5347\u7ea7\uff0c\u9700\u6d88\u8017150\u5361\u70b9\u6570\n\n9.\u623f\u5c4b\u964d\u7ea7\u5361\uff1a\u53ef\u4f7f\u5bf9\u65b9\u7684\u4efb\u4e00\u5730\u4ea7\u964d\u7ea7\uff0c\u9700\u6d88\u8017150\u5361\u70b9\u6570\n\n\u56db.\u5730\u56fe\u5730\u6807\u7b80\u5355\u8bf4\u660e   \n\n1.\u7a7a\u5730\uff1a\u7ecf\u8fc7\u65f6\u73a9\u5bb6\u53ef\u4ee5\u6839\u636e\u81ea\u5df1\u7684\u8d44\u91d1\u60c5\u51b5\u9009\u62e9\u662f\u5426\u8d2d\u4e70\u5730\u4ea7   \n\n2.\u533b\u9662\uff1a\u73a9\u5bb6\u7ecf\u8fc7\u65f6\u9700\u8981\u4f4f\u96622\u5929   \n\n3.\u77ff\u5730\uff1a\u73a9\u5bb6\u7ecf\u8fc7\u65f6\u53ef\u4ee5\u83b7\u5f97\u5361\u70b9\u6570200   \n\n4.\u76d1\u72f1\uff1a\u73a9\u5bb6\u7ecf\u8fc7\u65f6\u5c06\u88ab\u56da\u79813\u5929   \n\n5.\u9053\u5177\u5c4b\uff1a\u53ef\u83b7\u5f97\u8def\u969c\u5361\u3001\u70b8\u5f39\u5361\u3001\u505c\u7559\u5361\u3001\u673a\u5668\u5a03\u5a03   \n\n6.\u793c\u54c1\u5c4b\uff1a\u53ef\u83b7\u5f97\u5956\u52b1\uff1a\u8d44\u91d1\uffe52000\u3001\u5361\u70b9\u6570200\u3001\u8d22\u795e\u5361\u3001\u589e\u8d44\u5361   \n\n7.\u9b54\u6cd5\u5c4b\uff1a\u53ef\u83b7\u5f97\u8870\u795e\u5361\u3001\u623f\u5c4b\u964d\u7ea7\u5361");
		jScrollPane1.setViewportView(jTextArea1);

		jLabel1.setBackground(new java.awt.Color(232, 232, 251));
		jLabel1.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jLabel1.setText("\u6e38\u620f\u89c4\u5219");

		jButton1.setBackground(new java.awt.Color(204, 204, 255));
		jButton1.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jButton1.setText("\u8fd4     \u56de");
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				avoid();
			}
		});

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup().addContainerGap()
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(jPanel1Layout.createSequentialGroup().addGap(10, 10, 10).addComponent(
										jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 304, Short.MAX_VALUE))
								.addComponent(jLabel1))
						.addGap(31, 31, 31))
				.addGroup(jPanel1Layout.createSequentialGroup().addGap(122, 122, 122).addComponent(jButton1)
						.addContainerGap(134, Short.MAX_VALUE)));
		jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addComponent(jLabel1)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 308,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED).addComponent(jButton1)
						.addContainerGap(19, Short.MAX_VALUE)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		pack();
	}

	public static void main(String args[]) {
		new GameRule().setVisible(true);
	}

}