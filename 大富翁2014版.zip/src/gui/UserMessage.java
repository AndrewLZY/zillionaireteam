package gui;
import javax.swing.JFrame;

public class UserMessage extends javax.swing.JFrame {

	private static final long serialVersionUID = 1L;
	private javax.swing.JButton jButton3;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JTextArea jTextArea1;

	private void avoid() {
		this.dispose();
	}

	public UserMessage() {
		jPanel1 = new javax.swing.JPanel();
		jLabel1 = new javax.swing.JLabel();
		jScrollPane1 = new javax.swing.JScrollPane();
		jTextArea1 = new javax.swing.JTextArea();
		jButton3 = new javax.swing.JButton();

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		jPanel1.setBackground(new java.awt.Color(232, 232, 251));

		jLabel1.setFont(new java.awt.Font("���Ŀ���", 1, 20));
		jLabel1.setText("\u7528 \u6237 \u534f \u8bae");

		jTextArea1.setBackground(new java.awt.Color(251, 251, 241));
		jTextArea1.setColumns(20);
		jTextArea1.setFont(new java.awt.Font("���Ŀ���", 0, 14));
		jTextArea1.setRows(5);
		jTextArea1.setText(
				"1\u3001\u7279\u522b\u63d0\u793a\n   \u5927\u5bcc\u7fc1\u6e38\u620f\u540c\u610f\u6309\u7167\u672c\u534f\u8bae\u7684\u89c4\u5b9a\u53ca\u5176\u4e0d\u65f6\u53d1\u5e03\u7684\u64cd\u4f5c\u89c4\u5219\u63d0\u4f9b\u57fa\u4e8e\n\u4e92\u8054\u7f51\u7684\u76f8\u5173\u670d\u52a1\uff08\u4ee5\u4e0b\u79f0\u201c\u7f51\u7edc\u670d\u52a1\u201d\uff09\uff0c\u4e3a\u83b7\u5f97\u7f51\u7edc\u670d\u52a1\uff0c\u7528\u6237\u540c\n\u610f\u672c\u534f\u8bae\u7684\u5168\u90e8\u6761\u6b3e\u5e76\u6309\u7167\u9875\u9762\u4e0a\u7684\u63d0\u793a\u5b8c\u6210\u5168\u90e8\u7684\u6ce8\u518c\u7a0b\u5e8f\u3002\n2\u3001\u670d\u52a1\u5185\u5bb9\n   \u5927\u5bcc\u7fc1\u6e38\u620f\u7f51\u7edc\u670d\u52a1\u7684\u5177\u4f53\u5185\u5bb9\u7531\u5927\u5bcc\u7fc1\u6e38\u620f\u6839\u636e\u5b9e\u9645\u60c5\u51b5\u63d0\u4f9b\u3002\u5927\n\u5bcc\u7fc1\u6e38\u620f\u4fdd\u7559\u968f\u65f6\u53d8\u66f4\u3001\u4e2d\u65ad\u6216\u7ec8\u6b62\u90e8\u5206\u6216\u5168\u90e8\u7f51\u7edc\u670d\u52a1\u7684\u6743\u529b\u3002\n3\u3001\u4f7f\u7528\u89c4\u5219\n  3.1\u7528\u6237\u5728\u7533\u8bf7\u4f7f\u7528\u5927\u5bcc\u7fc1\u6e38\u620f\u65f6\uff0c\u52a1\u5fc5\u5411\u5927\u5bcc\u7fc1\u6e38\u620f\u7533\u8bf7\u6ce8\u518c\u5e76\u63d0\u4f9b\n\u51c6\u786e\u7684\u4e2a\u4eba\u8d44\u6599\u3002\u5982\u56e0\u4e2a\u4eba\u8d44\u6599\u4e0d\u6b63\u786e\u800c\u4e0d\u80fd\u4eab\u53d7\u76f8\u5173\u670d\u52a1\u65f6\uff0c\u5927\u5bcc\u7fc1\n\u6e38\u620f\u4e0d\u627f\u62c5\u4efb\u4f55\u8d23\u4efb\u3002\n  3.2\u7528\u6237\u540c\u610f\u63a5\u53d7\u5927\u5bcc\u7fc1\u6e38\u620f\u901a\u8fc7\u7535\u5b50\u90ae\u4ef6\u6216\u5176\u4ed6\u65b9\u5f0f\u5411\u7528\u6237\u53d1\u9001\u7684\n\u5546\u54c1\u4fc3\u9500\u6216\u5176\u4ed6\u76f8\u5173\u5546\u4e1a\u4fe1\u606f\u3002\n  3.3\u7528\u6237\u5728\u4f7f\u7528\u5927\u5bcc\u7fc1\u6e38\u620f\u7f51\u7edc\u670d\u52a1\u8fc7\u7a0b\u4e2d\uff0c\u5fc5\u987b\u9075\u5faa\u4ee5\u4e0b\u89c4\u5219\uff1a\n   \uff08A\uff09\u9075\u5b88\u4e2d\u56fd\u6709\u5173\u7684\u6cd5\u5f8b\u548c\u6cd5\u89c4\uff1b\n   \uff08B\uff09\u4e0d\u5f97\u4e3a\u4efb\u4f55\u975e\u6cd5\u76ee\u7684\u800c\u4f7f\u7528\u7f51\u7edc\u670d\u52a1\u7cfb\u7edf\uff1b\n   \uff08C\uff09\u9075\u5b88\u6240\u6709\u4e0e\u7f51\u7edc\u670d\u52a1\u6709\u5173\u7684\u7f51\u7edc\u534f\u8bae\u3001\u89c4\u5b9a\u548c\u7a0b\u5e8f\uff1b\n   \uff08D\uff09\u4e0d\u5f97\u5229\u7528\u5927\u5bcc\u7fc1\u6e38\u620f\u7f51\u7edc\u670d\u52a1\u7cfb\u7edf\u8fdb\u884c\u4efb\u4f55\u53ef\u80fd\u5bf9\u4e92\u8054\u7f51\u7684\u6b63\n            \u5e38\u8fd0\u884c\u9020\u6210\u4e0d\u5229\u5f71\u54cd\u7684\u884c\u4e3a\n    ......\n4\u3001\u5185\u5bb9\u6240\u6709\u6743\n   \u5927\u5bcc\u7fc1\u6e38\u620f\u63d0\u4f9b\u7684\u7f51\u7edc\u670d\u52a1\u5185\u5bb9\u53ef\u80fd\u5305\u62ec\uff1a\u6587\u5b57\u3001\u8f6f\u4ef6\u3001\u58f0\u97f3\u3001\u56fe\n\u7247\u3001\u5f55\u50cf\u56fe\u8868\u7b49\u3002\u6240\u6709\u8fd9\u4e9b\u5185\u5bb9\u53d7\u7248\u6743\u6cd5\u3001\u5546\u6807\u6cd5\u548c\u5176\u4ed6\u8d22\u4ea7\u6240\u6709\u6743\u6cd5\u5f8b\u7684\u4fdd\u62a4\u3002\n5\u3001\u9690\u79c1\u4fdd\u62a4\n   \u4fdd\u62a4\u7528\u6237\uff08\u7279\u522b\u662f\u672a\u6210\u5e74\u4eba\uff09\u7684\u9690\u79c1\u662f\u5927\u5bcc\u7fc1\u6e38\u620f\u7684\u4e00\u9879\u57fa\u672c\u653f\u7b56\u3002\n\u5927\u5bcc\u7fc1\u6e38\u620f\u4e0d\u5f97\u516c\u5f00\u7528\u6237\u7684\u4fe1\u606f\u4f46\u4e0b\u5217\u60c5\u51b5\u9664\u5916\uff1a\n   \uff08A\uff09\u4e8b\u5148\u83b7\u5f97\u7528\u6237\u7684\u660e\u786e\u6388\u6743\uff1b\n   \uff08B\uff09\u6839\u636e\u6709\u5173\u6cd5\u5f8b\u6cd5\u89c4\u8981\u6c42\uff1b\n   \uff08C\uff09\u6309\u7167\u76f8\u5173\u653f\u5e9c\u4e3b\u7ba1\u90e8\u95e8\u7684\u8981\u6c42\uff1b\n   \uff08D\uff09\u4e3a\u7ef4\u62a4\u793e\u4f1a\u516c\u4f17\u7684\u5229\u76ca\uff1b\n   \uff08E\uff09\u4e3a\u7ef4\u62a4\u5927\u5bcc\u7fc1\u6e38\u620f\u7684\u5408\u6cd5\u6743\u76ca\u3002 ");
		jTextArea1.setMargin(new java.awt.Insets(0, 0, 0, 0));
		jScrollPane1.setViewportView(jTextArea1);

		jButton3.setBackground(new java.awt.Color(232, 232, 251));
		jButton3.setFont(new java.awt.Font("���Ŀ���", 1, 20));
		jButton3.setForeground(new java.awt.Color(0, 0, 204));
		jButton3.setText("\u9000\u51fa");
		jButton3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
		jButton3.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				avoid();
			}
		});

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout
						.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addComponent(jScrollPane1,
								javax.swing.GroupLayout.DEFAULT_SIZE, 380, Short.MAX_VALUE))
						.addGroup(jPanel1Layout.createSequentialGroup().addGap(136, 136, 136).addComponent(jLabel1))
						.addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
								.addContainerGap(345, Short.MAX_VALUE).addComponent(jButton3)))
						.addContainerGap()));
		jPanel1Layout
				.setVerticalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addComponent(jLabel1)
								.addGap(18, 18, 18)
								.addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 308,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGap(18, 18, 18).addComponent(jButton3).addGap(14, 14, 14)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.PREFERRED_SIZE));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.PREFERRED_SIZE));

		pack();
	}

	public static void main(String args[]) {
		new UserMessage().setVisible(true);
	}

}