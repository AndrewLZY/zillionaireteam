package gui;

import person.PersonBasi;
import person.PersonBeibei;
import person.PersonTubo;
import person.PersonXiaomei;
import javax.swing.JFrame;

public class GameRole extends javax.swing.JFrame {

	private static final long serialVersionUID = 1L;
	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton2;
	private javax.swing.JButton jButton3;
	private javax.swing.JButton jButton4;
	private javax.swing.JButton jButton5;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JPanel jPanel1;

	private void avoid() {
		this.dispose();
	}

	public GameRole() {
		setBounds(550, 120, 0, 0);
		setTitle("\u89D2\u8272\u4ECB\u7ECD");
		jPanel1 = new javax.swing.JPanel();
		jLabel1 = new javax.swing.JLabel();
		jButton1 = new javax.swing.JButton();
		jButton2 = new javax.swing.JButton();
		jButton3 = new javax.swing.JButton();
		jButton4 = new javax.swing.JButton();
		jLabel2 = new javax.swing.JLabel();
		jButton5 = new javax.swing.JButton();

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBackground(new java.awt.Color(232, 232, 251));

		jPanel1.setBackground(new java.awt.Color(232, 232, 251));

		jLabel1.setBackground(new java.awt.Color(232, 232, 251));
		jLabel1.setFont(new java.awt.Font("���Ŀ���", 1, 18));
		jLabel1.setText("\u89d2\u8272\u4ecb\u7ecd");

		jButton1.setBackground(new java.awt.Color(232, 232, 251));
		jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/�𱴱�����.jpg"))); // NOI18N
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				new PersonBeibei().setVisible(true);
			}
		});

		jButton2.setBackground(new java.awt.Color(232, 232, 251));
		jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/��С������.jpg"))); // NOI18N
		jButton2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				new PersonXiaomei().setVisible(true);
			}
		});

		jButton3.setBackground(new java.awt.Color(232, 232, 251));
		jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/����������.jpg"))); // NOI18N
		jButton3.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				new PersonTubo().setVisible(true);
			}
		});

		jButton4.setBackground(new java.awt.Color(232, 232, 251));
		jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/ɳ¡��˹����.jpg"))); // NOI18N
		jButton4.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				new PersonBasi().setVisible(true);
			}
		});

		jLabel2.setBackground(new java.awt.Color(232, 232, 251));
		jLabel2.setFont(new java.awt.Font("���Ŀ���", 1, 14));
		jLabel2.setText(
				"\u4f60\u559c\u6b22\u6211\u4eec\u4e2d\u7684\u8c01\u5462\uff0c\u70b9\u51fb\u53ef\u4e86\u89e3\uff01");

		jButton5.setBackground(new java.awt.Color(204, 204, 255));
		jButton5.setFont(new java.awt.Font("���Ŀ���", 1, 16));
		jButton5.setText("\u8fd4\u56de");
		jButton5.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				avoid();
			}
		});

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addGroup(jPanel1Layout
						.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(jPanel1Layout.createSequentialGroup().addGap(10, 10, 10).addGroup(jPanel1Layout
								.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(jPanel1Layout
										.createSequentialGroup()
										.addGroup(jPanel1Layout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
												.addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 119,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 119,
														javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(jPanel1Layout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 119,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 119,
														javax.swing.GroupLayout.PREFERRED_SIZE)))
								.addComponent(jLabel2)))
						.addComponent(jLabel1)).addContainerGap(29, Short.MAX_VALUE))
				.addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
						.addContainerGap(217, Short.MAX_VALUE).addComponent(jButton5).addContainerGap()));
		jPanel1Layout
				.setVerticalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addComponent(jLabel1)
								.addGap(13, 13, 13)
								.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 121,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 121,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 121,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 121,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGap(18, 18, 18).addComponent(jLabel2)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(jButton5)
								.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		pack();
	}

	public static void main(String args[]) {
		new GameRole().setVisible(true);
	}
}
