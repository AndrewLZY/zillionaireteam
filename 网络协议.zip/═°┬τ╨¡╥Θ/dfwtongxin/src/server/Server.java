package server;

import java.io.*;
import java.net.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JOptionPane;
//import database.Mysql;
//import model.User;
//import login.LoginWay1;

public class Server implements Runnable {
	//��¼������
	int Finish = 1;// �ɹ�
	int passwdError = 0;// �������
	int userError = -1;// �û�������

	
	
	
	int LOGIN = 1;
	int REGISTER = 2;
	int USERLIST = 3;
	int ROLELIST = 4;
	int MUSICLIST = 5;
	int WINRECORD = 6;
	int LEVELRECORD = 7;
	int PROPCARD = 8;
	int MAP = 9;
	int BUILDING = 10;
	int GAMEPROGRESS = 11;
	int CHAT = 12;
	int RANDOMCARD = 13;
	int ROOM = 14;
	
	static ObjectOutputStream oos = null;
	static ObjectInputStream ois = null;

	Socket s;

	public Server() throws IOException, ClassNotFoundException, SQLException {

		ServerSocket ss = new ServerSocket(21213);
		System.out.println("�˿�21213");

		while (true) {
			s = ss.accept();
			System.out.println(s);
			new Thread(this).start();
		}
	}

	// login��¼
	public int LOGIN() throws IOException, ClassNotFoundException, SQLException {
		// Mysql mysql = new Mysql();
		// String name = ois.readUTF();
		// String passwd = ois.readUTF();
		// String sql =
		// String.format("select UserPasswd from UserList where UserName='%S'",
		// name);
		// ResultSet rs = mysql.stmt.executeQuery(sql);
		// while (rs.next()) {
		// if (rs.getString("UserPasswd").equals(passwd)) {
		// return Finish;
		// } else {
		// return passwdError;
		// }
		// }
		// return userError;
		return Finish;
	}

	// REGISTERע��
	public void REGISTER() throws IOException, ClassNotFoundException,
			SQLException {

		boolean isSelected = false;
//		Mysql mysql = new Mysql();
		String name = ois.readUTF();
		String passwd = ois.readUTF();
		String mail = ois.readUTF();
		String sql = String
				.format(
						"insert into UserList values(123,'%s','%s','%s',1,'1998-12-23','')",
						name, passwd, mail);
//		mysql.stmt.executeUpdate(sql);
		oos.writeObject(sql);
		oos.flush();

	}

	// Userlist�����Ϣ��
	public void USERLIST() throws IOException, ClassNotFoundException,
			SQLException {
		String Uid = ois.readUTF();
		String Uname = ois.readUTF();
		String Upw = ois.readUTF();
		String Umail = ois.readUTF();
		String Sex = ois.readUTF();
		String Birth = ois.readUTF();
		String userIcon = ois.readUTF();
		String Playerrole = ois.readUTF();

		oos.flush();
	}

	// Rolelist��ɫ��
	public void ROLELIST() throws IOException, ClassNotFoundException {
		String Rid = ois.readUTF();
		String Summary = ois.readUTF();
		String Role = ois.readUTF();

		oos.flush();

	}

	// Musiclist��Ч��
	public void MUSICLIST() throws IOException, ClassNotFoundException,
			SQLException {
		String Bname = ois.readUTF();
		String Bgm = ois.readUTF();
		String Bplace = ois.readUTF();

		oos.flush();
	}

	// Winrecordʤ����¼
	public void WINRECORD() throws IOException, ClassNotFoundException, SQLException {
//		Mysql mysql = new Mysql();
		String Uid = ois.readUTF();
		String datatime = ois.readUTF();
		String Playerrole = ois.readUTF();
		String sql =
			 String.format("insert into UserList values('%s','%s','%s')",
					 Uid,datatime,Playerrole);
//		mysql.stmt.executeUpdate(sql);
		oos.writeUTF("������ʤ����¼");
		oos.flush();

	}

	// Levelrecord�ؿ���¼
	public void LEVELRECORD() throws IOException, ClassNotFoundException,
			SQLException {
//		Mysql mysql = new Mysql();
		String Uid = ois.readUTF();
		String Playerrole = ois.readUTF();
		String Money = ois.readUTF();
		String sql =
			 String.format("insert into UserList values('%s','%s','%s')",
					 Uid,Playerrole,Money);
//		mysql.stmt.executeUpdate(sql);
		oos.writeUTF("�����ӹؿ���¼");
		oos.flush();
	}

	// Propcard���߿�
	public void PROPCARD() throws IOException, ClassNotFoundException {
		String propcard = ois.readUTF();
		String summary = ois.readUTF();

		oos.flush();

	}

	// Map��ͼ
	public void MAP() throws IOException, ClassNotFoundException, SQLException {
		String Mid = ois.readUTF();
		String Mapname = ois.readUTF();

		oos.flush();
	}

	// Building����
	public void BUILDING() throws IOException, ClassNotFoundException {
		String Bid = ois.readUTF();
		String Bname = ois.readUTF();
		String Mapname = ois.readUTF();
		String Owner = ois.readUTF();
		String Level = ois.readUTF();

		oos.flush();

	}

	// Gameprogress��Ϸ�浵��
	public void GAMEPROGRESS() throws IOException, ClassNotFoundException,
			SQLException {
//		Mysql mysql = new Mysql();
		String s = ois.readUTF();
		String Money = ois.readUTF();
		String Levelrecord = ois.readUTF();
		String Winrecord = ois.readUTF();
		String Playerrole = ois.readUTF();
		String sql =
			 String.format("insert into UserList values('%s','%s','%s','%s','%s')",
					 s,Money,Levelrecord,Winrecord,Playerrole);
//		mysql.stmt.executeUpdate(sql);
		oos.writeUTF("��������Ϸ�浵");
		oos.flush();
	}

	// Chat
	public void CHAT() throws IOException, ClassNotFoundException, SQLException {
//		Mysql mysql = new Mysql();
		String title = ois.readUTF();
		String Uid = ois.readUTF();
		String content = ois.readUTF();
		String time = ois.readUTF();
		String ip = ois.readUTF();
		String sql =
			 String.format("insert into UserList values('%s','%s','%s','%s','%s')",
					 title,Uid,content,time,ip);
//		mysql.stmt.executeUpdate(sql);
		oos.writeUTF("���ͳɹ�");
		oos.flush();

	}

	// Room����
	public void RANDOMCARD() throws IOException, ClassNotFoundException,
			SQLException {
		String Uid = ois.readUTF();
		String Rid = ois.readUTF();
		String Rname = ois.readUTF();
		String datatime = ois.readUTF();

		oos.flush();
	}

	// Randomcard�����
	public void ROOM() throws IOException, ClassNotFoundException {
		String Randcard = ois.readUTF();

		oos.flush();

	}

	public void run() {

		try {
			ois = new ObjectInputStream(s.getInputStream());
			oos = new ObjectOutputStream(s.getOutputStream());
			int command;
			command = ois.readInt();

			if (command == LOGIN) {
				System.out.println("�����˵�¼����");
				int status = LOGIN();
				oos.writeObject(status);
				oos.flush();
			}
			if (command == REGISTER) {
				REGISTER();
			}
			if (command == USERLIST) {
				USERLIST();
			}
			if (command == ROLELIST) {
				ROLELIST();
			}
			if (command == MUSICLIST) {
				MUSICLIST();
			}
			if (command == WINRECORD) {
				WINRECORD();
			}
			if (command == LEVELRECORD) {
				LEVELRECORD();
			}
			if (command == PROPCARD) {
				PROPCARD();
			}
			if (command == MAP) {
				MAP();
			}
			if (command == BUILDING) {
				BUILDING();
			}
			if (command == GAMEPROGRESS) {
				GAMEPROGRESS();
			}
			if (command == CHAT) {
				CHAT();
			}
			if (command == RANDOMCARD) {
				RANDOMCARD();
			}
			if (command == ROOM) {
				ROOM();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			System.out.println("�������пͻ���");
			new Server();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
