package server;

import java.sql.*;

public class Connect {

	private static Statement stat; 
	private static void init() throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/chat"
		,"root","123456"	);
		stat = con.createStatement();
		
	}
	public static Statement getStatement() throws ClassNotFoundException, SQLException{
		if(stat==null)
			init();
		return stat;
	}
}
