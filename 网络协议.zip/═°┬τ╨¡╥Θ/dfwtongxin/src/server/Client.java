package server;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.List;



public class Client extends Thread implements MyProtocal {

	static ObjectOutputStream oos = null;
	static ObjectInputStream ois = null;
	Socket s;

	public Client() throws UnknownHostException, IOException {
		s = new Socket("localhost", 21213);
		System.out.println(s);
		oos = new ObjectOutputStream(s.getOutputStream());
		ois = new ObjectInputStream(s.getInputStream());
		BufferedReader br = new BufferedReader(new InputStreamReader(ois));
	}

	// login��¼
	public int LOGIN(String name, String passwd) throws IOException,
			ClassNotFoundException {
		System.out.println("123");
		System.out.println(name);
		System.out.println(passwd);
		oos.writeInt(LOGIN);
		oos.flush();
		oos.writeUTF(name);
		oos.flush();
		oos.writeUTF(passwd);
		oos.flush();
		int status = ois.read();
		System.out.print(status);
		return status;
	}

	// REGISTERע��
	public void REGISTER(String name, String passwd, String mail)
			throws IOException, ClassNotFoundException {
		oos.writeInt(REGISTER);
		oos.flush();
		oos.writeUTF(name);
		oos.flush();
		oos.writeUTF(passwd);
		oos.flush();
		oos.writeUTF(mail);
		oos.flush();
//		User user = (User) ois.readObject();
//		if (!user.equals(null)) {
//			System.out.println("��������");
//		} else {
//			System.out.println("��½ʧ��");
//		}
	}

	// Userlist�����Ϣ��
	public String USERLIST(String Uid, String Uname, String Upw, String Umail,
			String Sex, String Birth, String userIcon, String Playerrole)
			throws IOException, ClassNotFoundException {
		oos.writeInt(USERLIST);
		oos.flush();
		oos.writeUTF(Uid);
		oos.flush();
		oos.writeUTF(Uname);
		oos.flush();
		oos.writeUTF(Umail);
		oos.flush();
		oos.writeUTF(Sex);
		oos.flush();
		oos.writeUTF(Birth);
		oos.flush();
		oos.writeUTF(userIcon);
		oos.flush();
		oos.writeUTF(Playerrole);
		oos.flush();

		return ois.readUTF();
	}

	// Rolelist��ɫ��
	public String ROLELIST(String Rid, String Summary, String Role)
			throws IOException, ClassNotFoundException {
		oos.writeInt(ROLELIST);
		oos.flush();
		oos.writeUTF(Rid);
		oos.flush();
		oos.writeUTF(Summary);
		oos.flush();
		oos.writeUTF(Role);
		oos.flush();

		return ois.readUTF();
	}

	// Musiclist��Ч��
	public String MUSICLIST(String Bname, String Bgm, String Bplace)
			throws IOException, ClassNotFoundException {
		oos.writeInt(MUSICLIST);
		oos.flush();
		oos.writeUTF(Bname);
		oos.flush();
		oos.writeUTF(Bgm);
		oos.flush();
		oos.writeUTF(Bplace);
		oos.flush();

		return ois.readUTF();
	}

	// Winrecordʤ����¼
	public String WINRECORD(String Uid, String datatime, String Playerrole,
			String Money) throws IOException, ClassNotFoundException {
		oos.writeInt(WINRECORD);
		oos.flush();
		oos.writeUTF(Uid);
		oos.flush();
		oos.writeUTF(datatime);
		oos.flush();
		oos.writeUTF(Playerrole);
		oos.flush();
		oos.writeUTF(Money);
		oos.flush();

		return ois.readUTF();
	}

	// Levelrecord�ؿ���¼
	public String LEVELRECORD(String Uid, String Playerrole, String Money)
			throws IOException, ClassNotFoundException {
		oos.writeInt(LEVELRECORD);
		oos.flush();
		oos.writeUTF(Uid);
		oos.flush();
		oos.writeUTF(Playerrole);
		oos.flush();
		oos.writeUTF(Money);
		oos.flush();

		return ois.readUTF();
	}

	// Propcard���߿�
	public String PROPCARD(String propcard, String summary) throws IOException,
			ClassNotFoundException {
		oos.writeInt(PROPCARD);
		oos.flush();
		oos.writeUTF(propcard);
		oos.flush();
		oos.writeUTF(summary);
		oos.flush();

		return ois.readUTF();
	}

	// Map��ͼ
	public String MAP(String Mid, String Mapname) throws IOException,
			ClassNotFoundException {
		oos.writeInt(MAP);
		oos.flush();
		oos.writeUTF(Mid);
		oos.flush();
		oos.writeUTF(Mapname);
		oos.flush();

		return ois.readUTF();
	}

	// Building����
	public String BUILDING(String Bid, String Bname, String Mapname,
			String Owner, String Level) throws IOException,
			ClassNotFoundException {
		oos.writeInt(BUILDING);
		oos.flush();
		oos.writeUTF(Bid);
		oos.flush();
		oos.writeUTF(Bname);
		oos.flush();
		oos.writeUTF(Mapname);
		oos.flush();
		oos.writeUTF(Owner);
		oos.flush();
		oos.writeUTF(Level);
		oos.flush();

		return ois.readUTF();
	}

	// Gameprogress��Ϸ�浵��
	public String GAMEPROGRESS(String Uid, String Money, String Levelrecord,
			String Winrecord, String Playerrole) throws IOException,
			ClassNotFoundException {
		oos.writeInt(GAMEPROGRESS);
		oos.flush();
		oos.writeUTF(Uid);
		oos.flush();
		oos.writeUTF(Money);
		oos.flush();
		oos.writeUTF(Levelrecord);
		oos.flush();
		oos.writeUTF(Winrecord);
		oos.flush();
		oos.writeUTF(Playerrole);
		oos.flush();

		return ois.readUTF();
	}

	// Chat
	public String CHAT(String title, String Uid, String content, String time,
			String ip) throws IOException, ClassNotFoundException {
		oos.writeInt(CHAT);
		oos.flush();
		oos.writeUTF(title);
		oos.flush();
		oos.writeUTF(Uid);
		oos.flush();
		oos.writeUTF(content);
		oos.flush();
		oos.writeUTF(time);
		oos.flush();
		oos.writeUTF(ip);
		oos.flush();

		return ois.readUTF();
	}

	// Room����
	public String ROOM(String Uid, String Rid, String Rname, String datatime)
			throws IOException, ClassNotFoundException {
		oos.writeInt(ROOM);
		oos.flush();
		oos.writeUTF(Uid);
		oos.flush();
		oos.writeUTF(Rid);
		oos.flush();
		oos.writeUTF(Rname);
		oos.flush();
		oos.writeUTF(datatime);
		oos.flush();

		return ois.readUTF();
	}

	// Randomcard�����
	public String RANDOMCARD(String Randcard) throws IOException,
			ClassNotFoundException {
		oos.writeInt(RANDOMCARD);
		oos.flush();
		oos.writeUTF(Randcard);
		oos.flush();

		return ois.readUTF();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			try {
				new Client().LOGIN("", "");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("���ӳɹ�");
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
