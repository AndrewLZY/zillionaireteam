package server;

public interface MyProtocal {
	int LOGIN=1;
	int REGISTER=2;
	int USERLIST =3;
	int ROLELIST =4;
	int MUSICLIST =5;
	int WINRECORD =6;
	int LEVELRECORD = 7;
	int PROPCARD = 8;
	int MAP = 9;
	int BUILDING = 10;
	int GAMEPROGRESS = 11;
	int CHAT = 12;
	int RANDOMCARD = 13;
	int ROOM = 14;
}
